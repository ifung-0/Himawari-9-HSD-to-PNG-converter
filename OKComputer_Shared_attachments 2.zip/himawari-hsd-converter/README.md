# Himawari-9 HSD to PNG Converter

[![Tests](https://github.com/YOUR_USERNAME/himawari-hsd-converter/actions/workflows/test.yml/badge.svg)](https://github.com/YOUR_USERNAME/himawari-hsd-converter/actions/workflows/test.yml)
[![Python 3.10+](https://img.shields.io/badge/python-3.10%2B-blue)](https://www.python.org/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

Convert Himawari-9 satellite data from HSD (Himawari Standard Data) format to downloadable PNG images. This tool provides both a web UI and API for easy conversion of satellite imagery.

![Himawari-9 Satellite](https://upload.wikimedia.org/wikipedia/commons/thumb/c/c7/Himawari-9_launch_on_H-IIA_F31.jpg/640px-Himawari-9_launch_on_H-IIA_F31.jpg)

## Features

- **Web UI** - Modern, responsive interface for easy conversion
- **REST API** - Programmatic access with `/convert` and `/health` endpoints
- **Custom HSD Parser** - Lightweight binary parser following JMA specification v1.3
- **Calibration Support** - Proper calibration for visible (albedo) and IR (brightness temperature) bands
- **Color Enhancements** - Multiple visualization options including IR color tables
- **Async Downloads** - Non-blocking HTTP with streaming for large files (up to 500MB)
- **GitHub Codespaces Ready** - One-click setup with `.devcontainer`

## Architecture

```
S3 URL (.dat.bz2)
    |
    v
[Download] --> [bzip2 Decompress] --> [HSD Parse] --> [Calibrate] --> [Render] --> [PNG]
    |                                    |                |              |
    |                                    v                v              v
    |                             Headers (meta)    Physical      Color Table
    |                             Pixel data (raw)  values        Stretch
    |
v
FastAPI (async)
```

## HSD Format

Himawari Standard Data (HSD) is the native format for Himawari-8/9 satellite observations. Each file contains:

- **12 sequential blocks** with block headers (block number + length)
- **Block 1-11**: Metadata (satellite info, projection, calibration, timestamps)
- **Block 12**: Pixel data (big-endian uint16 array)

See [JMA HSD User's Guide v1.3](https://www.data.jma.go.jp/mscweb/en/himawari89/space_segment/hsd_sample/HS_D_users_guide_en_v13.pdf) for complete specification.

### Observation Bands

| Band | Wavelength | Type | Resolution | Valid Bits |
|------|-----------|------|------------|------------|
| 1 | 0.47 μm | Visible (Blue) | 1km | 11 |
| 2 | 0.51 μm | Visible (Green) | 1km | 11 |
| 3 | 0.64 μm | Visible (Red) | 0.5km | 11 |
| 4 | 0.86 μm | NIR | 1km | 11 |
| 5 | 1.6 μm | NIR | 2km | 11 |
| 6 | 2.3 μm | NIR | 2km | 11 |
| 7-16 | 3.9-13.3 μm | Infrared | 2km | 11-14 |

## Performance

| File Type | Compressed Size | Processing Time | Output PNG |
|-----------|----------------|-----------------|------------|
| Band 1 (1km) | ~50-100 MB | ~10-20s | ~10-30 MB |
| Band 3 (0.5km) | ~150-300 MB | ~30-60s | ~40-80 MB |
| Band 13 (2km IR) | ~10-20 MB | ~5-10s | ~5-15 MB |

*Times measured on GitHub Codespaces standard instance (2-core, 4GB RAM)*

## Quick Start

### GitHub Codespaces (Recommended)

1. Click **Code** → **Codespaces** → **Create codespace on main**
2. Wait for container build (installs Python + dependencies)
3. Run: `python -m src.main`
4. Click **Open in Browser** when port 8000 notification appears

### Local Setup

```bash
# Clone repository
git clone https://github.com/YOUR_USERNAME/himawari-hsd-converter.git
cd himawari-hsd-converter

# Create virtual environment
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Run application
python -m src.main

# Open http://localhost:8000
```

## Usage

### Web UI

1. Go to [NOAA Himawari-9 Archive](https://noaa-himawari9.s3.amazonaws.com/index.html#AHI-L1b-FLDK/)
2. Navigate to a date/time folder
3. Copy a `.dat.bz2` URL (e.g., Band 1, Segment 1010)
4. Paste in the app, click **Convert**
5. Image downloads automatically

### API

```bash
# Convert a file to PNG
curl -o output.png "http://localhost:8000/convert?url=https://noaa-himawari9.s3.amazonaws.com/.../file.DAT.bz2&enhancement=albedo"

# Get file metadata
curl "http://localhost:8000/api/info?url=https://noaa-himawari9.s3.amazonaws.com/.../file.DAT.bz2"

# Health check
curl http://localhost:8000/health
```

### Enhancement Options

| Enhancement | Description | Best For |
|-------------|-------------|----------|
| `linear` | Auto band-based selection | General use |
| `albedo` | Reflectance 0-100% scaling | Visible bands (1-6) |
| `ir_color` | Color-enhanced temperature map | IR bands (7-16) |
| `ir_gray` | Inverted grayscale (cold=white) | IR bands (7-16) |

## Sample URLs for Testing

```
# Band 1 (Visible Blue) - 1km resolution
https://noaa-himawari9.s3.amazonaws.com/AHI-L1b-FLDK/2026/04/04/0400/HS_H09_20260404_0400_B01_FLDK_R10_S1010.DAT.bz2

# Band 3 (Visible Red) - 0.5km resolution
https://noaa-himawari9.s3.amazonaws.com/AHI-L1b-FLDK/2026/04/04/0400/HS_H09_20260404_0400_B03_FLDK_R05_S1010.DAT.bz2

# Band 13 (IR Window) - 2km resolution
https://noaa-himawari9.s3.amazonaws.com/AHI-L1b-FLDK/2026/04/04/0400/HS_H09_20260404_0400_B13_FLDK_R20_S1010.DAT.bz2
```

## Testing

```bash
# Run all tests
pytest

# Run with coverage
pytest --cov=src --cov-report=term

# Run specific test file
pytest tests/test_parser.py -v

# Download sample data for testing
python scripts/download_sample.py tests/fixtures
```

## Troubleshooting

### "File too large" error
The maximum file size is set to 500MB. For larger files (Band 3 full disk can be ~300MB compressed), the app should handle them within this limit.

### "Failed to decompress" error
The bz2 file may be corrupted or incomplete. Try downloading the file again.

### Timeout during download
Large files on slow connections may timeout. The default timeout is 5 minutes. For very large files, consider using a smaller segment or lower resolution band.

### Memory issues
Full disk Band 3 (0.5km) images can require 2GB+ RAM. If you encounter memory issues, try:
- Using Band 1 or Band 13 (smaller files)
- Running on a machine with more RAM
- Processing a segment file instead of full disk

## Project Structure

```
.
├── .devcontainer/
│   └── devcontainer.json       # GitHub Codespaces config
├── .github/
│   └── workflows/
│       └── test.yml            # CI/CD pipeline
├── src/
│   ├── __init__.py
│   ├── main.py                 # FastAPI application
│   ├── hsd_parser.py           # HSD binary parser
│   ├── calibration.py          # Calibration functions
│   ├── renderer.py             # Image rendering & color tables
│   └── templates/
│       └── index.html          # Web UI
├── tests/
│   ├── test_parser.py          # Parser unit tests
│   ├── test_api.py             # API endpoint tests
│   └── fixtures/               # Test data files
├── scripts/
│   └── download_sample.py      # Sample data downloader
├── requirements.txt
├── requirements-dev.txt
├── README.md
├── QUICKSTART.md
└── LICENSE
```

## Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Make your changes
4. Run tests (`pytest`)
5. Commit your changes (`git commit -m 'Add amazing feature'`)
6. Push to the branch (`git push origin feature/amazing-feature`)
7. Open a Pull Request

### Reporting Issues

Please include:
- Error message and traceback
- URL you were trying to convert
- Browser/client used
- Python version (`python --version`)

## Acknowledgments

- **JMA** (Japan Meteorological Agency) - Himawari-9 satellite operations and data format specification
- **NOAA** - Public data archive hosting
- **JAXA** - Satellite operations and data distribution

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Disclaimer

This tool is not officially affiliated with JMA, NOAA, or JAXA. Himawari-9 data is provided for public use. Please cite JMA/NOAA when using the data in publications.
