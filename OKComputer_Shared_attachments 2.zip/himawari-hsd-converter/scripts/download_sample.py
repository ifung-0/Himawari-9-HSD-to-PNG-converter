#!/usr/bin/env python3
"""
Helper script to download sample Himawari-9 HSD data for testing.

Usage:
    python scripts/download_sample.py [output_dir]

Downloads a small sample file (Band 1, 1km resolution) from the NOAA archive.
"""

import sys
import os
from pathlib import Path
import httpx

# Default sample URL - Band 1 (Visible), 1km resolution, smaller file
SAMPLE_URL = (
    "https://noaa-himawari9.s3.amazonaws.com/"
    "AHI-L1b-FLDK/2026/04/04/0400/"
    "HS_H09_20260404_0400_B01_FLDK_R10_S1010.DAT.bz2"
)


def download_file(url: str, output_path: Path) -> None:
    """Download a file with progress reporting."""
    print(f"Downloading: {url}")
    print(f"Output: {output_path}")
    
    with httpx.Client(timeout=300.0, follow_redirects=True) as client:
        with client.stream("GET", url) as response:
            response.raise_for_status()
            
            total_size = int(response.headers.get("content-length", 0))
            if total_size:
                print(f"File size: {total_size / 1024 / 1024:.1f} MB")
            
            downloaded = 0
            chunk_size = 1024 * 1024  # 1MB
            
            with open(output_path, "wb") as f:
                for chunk in response.iter_bytes(chunk_size=chunk_size):
                    f.write(chunk)
                    downloaded += len(chunk)
                    if total_size:
                        pct = downloaded / total_size * 100
                        print(f"\rProgress: {pct:.1f}% ({downloaded/1024/1024:.1f} MB)", end="", flush=True)
    
    print(f"\nDownload complete: {output_path}")
    file_size = output_path.stat().st_size
    print(f"File size: {file_size / 1024 / 1024:.1f} MB")


def main():
    output_dir = Path(sys.argv[1]) if len(sys.argv) > 1 else Path("tests/fixtures")
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # Extract filename from URL
    filename = SAMPLE_URL.split("/")[-1]
    output_path = output_dir / filename
    
    if output_path.exists():
        print(f"File already exists: {output_path}")
        overwrite = input("Overwrite? [y/N]: ").lower().strip()
        if overwrite != "y":
            print("Skipping download.")
            return
    
    try:
        download_file(SAMPLE_URL, output_path)
        print("\n✓ Sample data downloaded successfully!")
        print(f"  Location: {output_path.absolute()}")
        print("\nYou can now use this file for testing:")
        print(f"  URL: {SAMPLE_URL}")
    except Exception as e:
        print(f"\n✗ Download failed: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
