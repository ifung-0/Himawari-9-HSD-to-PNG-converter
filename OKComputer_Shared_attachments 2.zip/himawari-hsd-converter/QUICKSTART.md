# Quick Start Guide

Get the Himawari-9 HSD Converter running in under 5 minutes.

## Option 1: GitHub Codespaces (Fastest - No local install)

### Step 1: Create Codespace
1. Go to your repository on GitHub
2. Click the green **<> Code** button
3. Select **Codespaces** tab
4. Click **Create codespace on main**

### Step 2: Wait for Setup
The container will automatically:
- Install Python 3.11
- Install all dependencies from `requirements.txt`
- Configure port forwarding

This takes about 1-2 minutes.

### Step 3: Run the App
```bash
python -m src.main
```

### Step 4: Open in Browser
When you see the popup "Your application running on port 8000 is available", click **Open in Browser**.

The app will be available at a URL like `https://YOUR_CODESPACE-8000.github.dev`

---

## Option 2: Local Setup

### Prerequisites
- Python 3.10 or newer
- pip
- git

### Step 1: Clone and Setup
```bash
git clone https://github.com/YOUR_USERNAME/himawari-hsd-converter.git
cd himawari-hsd-converter

python -m venv venv

# Linux/macOS:
source venv/bin/activate

# Windows:
venv\Scripts\activate

pip install -r requirements.txt
```

### Step 2: Run
```bash
python -m src.main
```

### Step 3: Open
Go to http://localhost:8000 in your browser.

---

## Using the Converter

### Step 1: Find Data
1. Go to https://noaa-himawari9.s3.amazonaws.com/index.html#AHI-L1b-FLDK/
2. Navigate to a date (e.g., `2026/04/04/0400/`)
3. You'll see a list of `.DAT.bz2` files

### Step 2: Copy URL
Right-click on a file and copy the link. Example:
```
https://noaa-himawari9.s3.amazonaws.com/AHI-L1b-FLDK/2026/04/04/0400/HS_H09_20260404_0400_B01_FLDK_R10_S1010.DAT.bz2
```

### Step 3: Paste and Convert
1. Paste the URL into the input field on the web UI
2. Select enhancement type (or leave as "Auto")
3. Click **Convert to PNG**
4. Wait for processing (10-60 seconds depending on file size)
5. The image will download automatically

### Understanding the File Names
```
HS_H09_20260404_0400_B01_FLDK_R10_S1010.DAT.bz2
  │   │    │      │   │   │    │   │
  │   │    │      │   │   │    │   └── Segment 1 of 10
  │   │    │      │   │   │    └────── Resolution: 10=1km, 05=0.5km, 20=2km
  │   │    │      │   │   └─────────── Area: FLDK=Full Disk
  │   │    │      │   └─────────────── Band: 01=Visible Blue
  │   │    │      └─────────────────── Time: 04:00 UTC
  │   │    └────────────────────────── Date: 2026-04-04
  │   └─────────────────────────────── Satellite: H09=Himawari-9
  └─────────────────────────────────── HS=Himawari Standard Data
```

---

## Quick Test URLs

| Band | Type | URL |
|------|------|-----|
| B01 | Visible (Blue) | `https://noaa-himawari9.s3.amazonaws.com/AHI-L1b-FLDK/2026/04/04/0400/HS_H09_20260404_0400_B01_FLDK_R10_S1010.DAT.bz2` |
| B03 | Visible (Red) | `https://noaa-himawari9.s3.amazonaws.com/AHI-L1b-FLDK/2026/04/04/0400/HS_H09_20260404_0400_B03_FLDK_R05_S1010.DAT.bz2` |
| B13 | IR (10.4μm) | `https://noaa-himawari9.s3.amazonaws.com/AHI-L1b-FLDK/2026/04/04/0400/HS_H09_20260404_0400_B13_FLDK_R20_S1010.DAT.bz2` |

---

## Enhancement Guide

| Enhancement | Best For | Result |
|-------------|----------|--------|
| **Auto** | Any band | Automatically selects best option |
| **Albedo** | Visible bands 1-6 | Shows reflectance (grayscale) |
| **IR Color** | IR bands 7-16 | Color temperature map |
| **IR Gray** | IR bands 7-16 | Black/white temperature map |

---

## Troubleshooting

### Port 8000 is already in use
```bash
python -m src.main --port 8080
```

### Module not found errors
Make sure you activated the virtual environment:
```bash
source venv/bin/activate  # Linux/macOS
venv\Scripts\activate     # Windows
```

### Download very slow
The NOAA S3 bucket can be slow. Try:
- Using a smaller band (Band 13 is ~10MB vs Band 3 ~200MB)
- Running from a cloud instance (GitHub Codespaces, AWS, etc.)

### "File too large" error
The maximum is 500MB. Most files should be under this limit. Try a different time slot or band.

---

## Running Tests

```bash
# Install dev dependencies
pip install -r requirements-dev.txt

# Run tests
pytest

# Run with verbose output
pytest -v

# Run specific test
pytest tests/test_parser.py::TestFullHSDFile::test_parse_visible_band -v
```

---

## Next Steps

- **API Access**: See `README.md` for API documentation
- **HSD Format**: Read the [JMA specification](https://www.data.jma.go.jp/mscweb/en/himawari89/space_segment/hsd_sample/HS_D_users_guide_en_v13.pdf)
- **RGB Composites**: Combine multiple bands for color images
- **Batch Processing**: Use the API with a script to process multiple files

---

## Getting Help

- **Issues**: https://github.com/YOUR_USERNAME/himawari-hsd-converter/issues
- **Discussions**: https://github.com/YOUR_USERNAME/himawari-hsd-converter/discussions
