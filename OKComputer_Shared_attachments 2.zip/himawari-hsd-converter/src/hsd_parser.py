"""
Himawari Standard Data (HSD) Binary Parser

Parses Himawari-8/9 HSD format files according to JMA specification v1.3.
HSD files consist of sequential blocks, each starting with a 4-byte header
(block number + block length), followed by block content.

Block Structure:
    [Block Header: 4 bytes] [Block Content: variable]
    - Block Number (uint16, big-endian)
    - Block Length (uint16, big-endian)
"""

import struct
import logging
from dataclasses import dataclass, field
from typing import Dict, Any, Optional, Tuple
import numpy as np

logger = logging.getLogger(__name__)

# Block numbers as defined in the HSD specification
BLOCK_BASIC_INFO = 1
BLOCK_DATA_INFO = 2
BLOCK_PROJECTION = 3
BLOCK_NAVIGATION = 4
BLOCK_CALIBRATION = 5
BLOCK_INTER_CALIBRATION = 6
BLOCK_SEGMENT = 7
BLOCK_NAV_CORRECTION = 8
BLOCK_OBS_TIME = 9
BLOCK_ERROR = 10
BLOCK_SPARE = 11
BLOCK_DATA = 12

# Valid bits per pixel for each band (from Table 1)
BAND_VALID_BITS = {
    1: 11, 2: 11, 3: 11, 4: 11, 5: 11, 6: 11,
    7: 14, 8: 11, 9: 11, 10: 12, 11: 12, 12: 12,
    13: 12, 14: 12, 15: 12, 16: 11
}


@dataclass
class HSDHeaders:
    """Container for all parsed HSD header blocks."""
    basic_info: Dict[str, Any] = field(default_factory=dict)
    data_info: Dict[str, Any] = field(default_factory=dict)
    projection: Dict[str, Any] = field(default_factory=dict)
    navigation: Dict[str, Any] = field(default_factory=dict)
    calibration: Dict[str, Any] = field(default_factory=dict)
    inter_calibration: Dict[str, Any] = field(default_factory=dict)
    segment: Dict[str, Any] = field(default_factory=dict)
    nav_correction: Dict[str, Any] = field(default_factory=dict)
    obs_time: Dict[str, Any] = field(default_factory=dict)
    error_info: Dict[str, Any] = field(default_factory=dict)
    spare: Dict[str, Any] = field(default_factory=dict)

    def get_band_number(self) -> int:
        """Get band number from calibration block."""
        return self.calibration.get("band_number", 0)

    def get_bits_per_pixel(self) -> int:
        """Get bits per pixel from data info block."""
        return self.data_info.get("bits_per_pixel", 16)

    def get_dimensions(self) -> Tuple[int, int]:
        """Get (lines, columns) from data info block."""
        return (
            self.data_info.get("number_of_lines", 0),
            self.data_info.get("number_of_columns", 0)
        )

    def get_satellite_name(self) -> str:
        """Get satellite name from basic info."""
        return self.basic_info.get("satellite_name", "Unknown")

    def get_observation_area(self) -> str:
        """Get observation area from basic info."""
        return self.basic_info.get("observation_area", "Unknown")

    def get_file_name(self) -> str:
        """Get file name from basic info."""
        return self.basic_info.get("file_name", "")


def parse_basic_info_block(content: bytes) -> Dict[str, Any]:
    """Parse Block #1: Basic Information (282 bytes).
    
    Note: content includes the 3-byte internal header (block_num + block_len)
    that must be skipped before reading actual fields.
    """
    result = {}
    offset = 0
    # Skip internal block header (1 byte block num + 2 bytes block len)
    offset += 3
    # 3: Total number of header blocks (2 bytes)
    result["total_header_blocks"] = struct.unpack(">H", content[offset:offset+2])[0]
    offset += 2
    # 4: Byte order (1 byte)
    result["byte_order"] = content[offset]
    offset += 1
    # 5: Satellite name (16 bytes ASCII)
    result["satellite_name"] = content[offset:offset+16].decode('ascii').strip('\x00').strip()
    offset += 16
    # 6: Processing center name (16 bytes ASCII)
    result["processing_center"] = content[offset:offset+16].decode('ascii').strip('\x00').strip()
    offset += 16
    # 7: Observation area (4 bytes ASCII)
    result["observation_area"] = content[offset:offset+4].decode('ascii').strip('\x00').strip()
    offset += 4
    # 8: Other observation information (2 bytes ASCII)
    result["other_obs_info"] = content[offset:offset+2].decode('ascii').strip('\x00').strip()
    offset += 2
    # 9: Observation timeline (2 bytes)
    result["observation_timeline"] = struct.unpack(">H", content[offset:offset+2])[0]
    offset += 2
    # 10: Observation start time (8 bytes double - MJD)
    result["observation_start_time"] = struct.unpack(">d", content[offset:offset+8])[0]
    offset += 8
    # 11: Observation end time (8 bytes double - MJD)
    result["observation_end_time"] = struct.unpack(">d", content[offset:offset+8])[0]
    offset += 8
    # 12: File creation time (8 bytes double - MJD)
    result["file_creation_time"] = struct.unpack(">d", content[offset:offset+8])[0]
    offset += 8
    # 13: Total header length (4 bytes)
    result["total_header_length"] = struct.unpack(">I", content[offset:offset+4])[0]
    offset += 4
    # 14: Total data length (4 bytes)
    result["total_data_length"] = struct.unpack(">I", content[offset:offset+4])[0]
    offset += 4
    # 15: Spare (40 bytes) - skip
    offset += 40
    # 16: Quality flag 1 (1 byte)
    result["quality_flag_1"] = content[offset]
    offset += 1
    # 17: Quality flag 2 (1 byte)
    result["quality_flag_2"] = content[offset]
    offset += 1
    # 18: Quality flag 3 (1 byte)
    result["quality_flag_3"] = content[offset]
    offset += 1
    # 19: Quality flag 4 (1 byte)
    result["quality_flag_4"] = content[offset]
    offset += 1
    # 20: File format version (32 bytes ASCII)
    result["file_format_version"] = content[offset:offset+32].decode('ascii').strip('\x00').strip()
    offset += 32
    # 21: File name (128 bytes ASCII)
    result["file_name"] = content[offset:offset+128].decode('ascii').strip('\x00').strip()
    offset += 128
    # 22: Spare (40 bytes)
    offset += 40

    return result


def parse_data_info_block(content: bytes) -> Dict[str, Any]:
    """Parse Block #2: Data Information (50 bytes).
    
    Note: content includes the 3-byte internal header (block_num + block_len)
    that must be skipped before reading actual fields.
    """
    result = {}
    offset = 0
    # Skip internal block header (1 byte block num + 2 bytes block len)
    offset += 3
    # 3: Number of bits per pixel (2 bytes)
    result["bits_per_pixel"] = struct.unpack(">H", content[offset:offset+2])[0]
    offset += 2
    # 4: Number of columns (2 bytes)
    result["number_of_columns"] = struct.unpack(">H", content[offset:offset+2])[0]
    offset += 2
    # 5: Number of lines (2 bytes)
    result["number_of_lines"] = struct.unpack(">H", content[offset:offset+2])[0]
    offset += 2
    # 6: Compression flag (1 byte)
    result["compression_flag"] = content[offset]
    offset += 1
    # 7: Spare (40 bytes)
    offset += 40

    return result


def parse_projection_block(content: bytes) -> Dict[str, Any]:
    """Parse Block #3: Projection Information (127 bytes).
    
    Note: content includes the 3-byte internal header (block_num + block_len)
    that must be skipped before reading actual fields.
    """
    result = {}
    offset = 0
    # Skip internal block header (1 byte block num + 2 bytes block len)
    offset += 3
    # 3: sub_lon (8 bytes double)
    result["sub_lon"] = struct.unpack(">d", content[offset:offset+8])[0]
    offset += 8
    # 4: CFAC (4 bytes uint32)
    result["cfac"] = struct.unpack(">I", content[offset:offset+4])[0]
    offset += 4
    # 5: LFAC (4 bytes uint32)
    result["lfac"] = struct.unpack(">I", content[offset:offset+4])[0]
    offset += 4
    # 6: COFF (4 bytes float)
    result["coff"] = struct.unpack(">f", content[offset:offset+4])[0]
    offset += 4
    # 7: LOFF (4 bytes float)
    result["loff"] = struct.unpack(">f", content[offset:offset+4])[0]
    offset += 4
    # 8: Distance from Earth's center to satellite (8 bytes double)
    result["distance"] = struct.unpack(">d", content[offset:offset+8])[0]
    offset += 8
    # 9: Earth's equatorial radius (8 bytes double)
    result["equatorial_radius"] = struct.unpack(">d", content[offset:offset+8])[0]
    offset += 8
    # 10: Earth's polar radius (8 bytes double)
    result["polar_radius"] = struct.unpack(">d", content[offset:offset+8])[0]
    offset += 8
    # 11: (req2 - rpol2) / req2 (8 bytes double)
    result["eccentricity_sq"] = struct.unpack(">d", content[offset:offset+8])[0]
    offset += 8
    # 12: rpol2 / req2 (8 bytes double)
    result["polar_ratio_sq"] = struct.unpack(">d", content[offset:offset+8])[0]
    offset += 8
    # 13: req2 / rpol2 (8 bytes double)
    result["equatorial_ratio_sq"] = struct.unpack(">d", content[offset:offset+8])[0]
    offset += 8
    # 14: Coefficient for Sd (8 bytes double)
    result["sd_coefficient"] = struct.unpack(">d", content[offset:offset+8])[0]
    offset += 8
    # 15: Resampling types (2 bytes) - skip
    offset += 2
    # 16: Resampling size (2 bytes) - skip
    offset += 2
    # 17: Spare (40 bytes)
    offset += 40

    return result


def parse_navigation_block(content: bytes) -> Dict[str, Any]:
    """Parse Block #4: Navigation Information (~139 bytes).
    
    Note: content includes the 3-byte internal header (block_num + block_len)
    that must be skipped before reading actual fields.
    """
    result = {}
    offset = 0
    # Skip internal block header (1 byte block num + 2 bytes block len)
    offset += 3
    # 3: Navigation information time (8 bytes double - MJD)
    result["nav_time"] = struct.unpack(">d", content[offset:offset+8])[0]
    offset += 8
    # 4: SSP longitude (8 bytes double)
    result["ssp_lon"] = struct.unpack(">d", content[offset:offset+8])[0]
    offset += 8
    # 5: SSP latitude (8 bytes double)
    result["ssp_lat"] = struct.unpack(">d", content[offset:offset+8])[0]
    offset += 8
    # 6: Distance from Earth's center to Satellite (8 bytes double)
    result["satellite_distance"] = struct.unpack(">d", content[offset:offset+8])[0]
    offset += 8
    # 7: Nadir longitude (8 bytes double)
    result["nadir_lon"] = struct.unpack(">d", content[offset:offset+8])[0]
    offset += 8
    # 8: Nadir latitude (8 bytes double)
    result["nadir_lat"] = struct.unpack(">d", content[offset:offset+8])[0]
    offset += 8
    # 9: Sun's position (8*3 = 24 bytes double[3])
    sun_x = struct.unpack(">d", content[offset:offset+8])[0]
    sun_y = struct.unpack(">d", content[offset+8:offset+16])[0]
    sun_z = struct.unpack(">d", content[offset+16:offset+24])[0]
    result["sun_position"] = (sun_x, sun_y, sun_z)
    offset += 24
    # 10: Moon's position (8*3 = 24 bytes double[3])
    moon_x = struct.unpack(">d", content[offset:offset+8])[0]
    moon_y = struct.unpack(">d", content[offset+8:offset+16])[0]
    moon_z = struct.unpack(">d", content[offset+16:offset+24])[0]
    result["moon_position"] = (moon_x, moon_y, moon_z)
    offset += 24
    # 11: Spare (40 bytes)
    offset += 40

    return result


def parse_calibration_block(content: bytes) -> Dict[str, Any]:
    """Parse Block #5: Calibration Information (147 bytes).
    
    Note: content includes the 3-byte internal header (block_num + block_len)
    that must be skipped before reading actual fields.
    """
    result = {}
    offset = 0
    # Skip internal block header (1 byte block num + 2 bytes block len)
    offset += 3
    # 3: Band number (2 bytes)
    result["band_number"] = struct.unpack(">H", content[offset:offset+2])[0]
    offset += 2
    # 4: Central wave length (8 bytes double)
    result["central_wavelength"] = struct.unpack(">d", content[offset:offset+8])[0]
    offset += 8
    # 5: Valid number of bits per pixel (2 bytes)
    result["valid_bits_per_pixel"] = struct.unpack(">H", content[offset:offset+2])[0]
    offset += 2
    # 6: Count value of error pixels (2 bytes)
    result["error_pixel_count"] = struct.unpack(">H", content[offset:offset+2])[0]
    offset += 2
    # 7: Count value of pixels outside scan area (2 bytes)
    result["outside_scan_count"] = struct.unpack(">H", content[offset:offset+2])[0]
    offset += 2

    band_num = result.get("band_number", 0)

    if 1 <= band_num <= 6:
        # Visible / Near-Infrared bands
        # 8: Slope for count-radiance conversion (8 bytes double)
        result["slope"] = struct.unpack(">d", content[offset:offset+8])[0]
        offset += 8
        # 9: Intercept for count-radiance conversion (8 bytes double)
        result["intercept"] = struct.unpack(">d", content[offset:offset+8])[0]
        offset += 8
        # 10: Coefficient c' for radiance to albedo (8 bytes double)
        result["c_prime"] = struct.unpack(">d", content[offset:offset+8])[0]
        offset += 8
        # 11: Update time (8 bytes double MJD)
        result["calibration_update_time"] = struct.unpack(">d", content[offset:offset+8])[0]
        offset += 8
        # 12: Updated slope (8 bytes double)
        result["updated_slope"] = struct.unpack(">d", content[offset:offset+8])[0]
        offset += 8
        # 13: Updated intercept (8 bytes double)
        result["updated_intercept"] = struct.unpack(">d", content[offset:offset+8])[0]
        offset += 8
        # 14-18: Spare for visible bands (8*5 = 40 bytes)
        offset += 40
    else:
        # IR bands (7-16)
        # 8: Slope for count-radiance conversion (8 bytes double)
        result["slope"] = struct.unpack(">d", content[offset:offset+8])[0]
        offset += 8
        # 9: Intercept for count-radiance conversion (8 bytes double)
        result["intercept"] = struct.unpack(">d", content[offset:offset+8])[0]
        offset += 8
        # 10: c0 for radiance to BT (8 bytes double)
        result["c0"] = struct.unpack(">d", content[offset:offset+8])[0]
        offset += 8
        # 11: c1 (8 bytes double)
        result["c1"] = struct.unpack(">d", content[offset:offset+8])[0]
        offset += 8
        # 12: c2 (8 bytes double)
        result["c2"] = struct.unpack(">d", content[offset:offset+8])[0]
        offset += 8
        # 13: C0 for BT to radiance (8 bytes double)
        result["C0"] = struct.unpack(">d", content[offset:offset+8])[0]
        offset += 8
        # 14: C1 (8 bytes double)
        result["C1"] = struct.unpack(">d", content[offset:offset+8])[0]
        offset += 8
        # 15: C2 (8 bytes double)
        result["C2"] = struct.unpack(">d", content[offset:offset+8])[0]
        offset += 8
        # 16: Speed of light (8 bytes double)
        result["speed_of_light"] = struct.unpack(">d", content[offset:offset+8])[0]
        offset += 8
        # 17: Planck constant (8 bytes double)
        result["planck_constant"] = struct.unpack(">d", content[offset:offset+8])[0]
        offset += 8
        # 18: Boltzmann constant (8 bytes double)
        result["boltzmann_constant"] = struct.unpack(">d", content[offset:offset+8])[0]
        offset += 8
        # 19: Spare (40 bytes)
        offset += 40

    return result


def parse_inter_calibration_block(content: bytes) -> Dict[str, Any]:
    """Parse Block #6: Inter-calibration Information (259 bytes).
    
    Note: content includes the 3-byte internal header (block_num + block_len)
    that must be skipped before reading actual fields.
    """
    result = {}
    offset = 0
    # Skip internal block header (1 byte block num + 2 bytes block len)
    offset += 3
    # 3: GSICS calibration coefficient Intercept (8 bytes double)
    result["gsics_intercept"] = struct.unpack(">d", content[offset:offset+8])[0]
    offset += 8
    # 4: GSICS calibration coefficient Slope (8 bytes double)
    result["gsics_slope"] = struct.unpack(">d", content[offset:offset+8])[0]
    offset += 8
    # 5: GSICS calibration coefficient Quadratic term (8 bytes double)
    result["gsics_quadratic"] = struct.unpack(">d", content[offset:offset+8])[0]
    offset += 8
    # 6: Radiance bias for standard scene (8 bytes double)
    result["radiance_bias"] = struct.unpack(">d", content[offset:offset+8])[0]
    offset += 8
    # 7: Uncertainty of radiance bias (8 bytes double)
    result["radiance_bias_uncertainty"] = struct.unpack(">d", content[offset:offset+8])[0]
    offset += 8
    # 8: Radiance/Temp for standard scene (8 bytes double)
    result["standard_scene_value"] = struct.unpack(">d", content[offset:offset+8])[0]
    offset += 8
    # 9: Start time of GSICS Correction validity (8 bytes double MJD)
    result["gsics_start_time"] = struct.unpack(">d", content[offset:offset+8])[0]
    offset += 8
    # 10: End time of GSICS Correction validity (8 bytes double MJD)
    result["gsics_end_time"] = struct.unpack(">d", content[offset:offset+8])[0]
    offset += 8
    # 11: Radiance validity range upper (4 bytes float)
    result["validity_range_upper"] = struct.unpack(">f", content[offset:offset+4])[0]
    offset += 4
    # 12: Radiance validity range lower (4 bytes float)
    result["validity_range_lower"] = struct.unpack(">f", content[offset:offset+4])[0]
    offset += 4
    # 13: File name of GSICS Correction (128 bytes ASCII)
    result["gsics_filename"] = content[offset:offset+128].decode('ascii').strip('\x00').strip()
    offset += 128
    # 14: Spare (56 bytes)
    offset += 56

    return result


def parse_segment_block(content: bytes) -> Dict[str, Any]:
    """Parse Block #7: Segment Information (47 bytes).
    
    Note: content includes the 3-byte internal header (block_num + block_len)
    that must be skipped before reading actual fields.
    """
    result = {}
    offset = 0
    # Skip internal block header (1 byte block num + 2 bytes block len)
    offset += 3
    # 3: Total number of segments (1 byte)
    result["total_segments"] = content[offset]
    offset += 1
    # 4: Segment sequence number (1 byte)
    result["segment_number"] = content[offset]
    offset += 1
    # 5: First line number of image segment (2 bytes)
    result["first_line_number"] = struct.unpack(">H", content[offset:offset+2])[0]
    offset += 2
    # 6: Spare (40 bytes)
    offset += 40

    return result


def parse_nav_correction_block(content: bytes) -> Dict[str, Any]:
    """Parse Block #8: Navigation Correction Information (variable)."""
    result = {}
    if len(content) < 15:
        return result

    offset = 0
    # Skip internal block header (1 byte block num + 2 bytes block len)
    offset += 3
    # 3: Center column of rotation (4 bytes float)
    result["center_column"] = struct.unpack(">f", content[offset:offset+4])[0]
    offset += 4
    # 4: Center line of rotation (4 bytes float)
    result["center_line"] = struct.unpack(">f", content[offset:offset+4])[0]
    offset += 4
    # 5: Amount of rotational correction (8 bytes double)
    result["rotational_correction"] = struct.unpack(">d", content[offset:offset+8])[0]
    offset += 8
    # 6: Number of correction info data (2 bytes)
    result["num_corrections"] = struct.unpack(">H", content[offset:offset+2])[0]
    offset += 2

    corrections = []
    for _ in range(result.get("num_corrections", 0)):
        if offset + 10 > len(content):
            break
        line_num = struct.unpack(">H", content[offset:offset+2])[0]
        col_shift = struct.unpack(">f", content[offset+2:offset+6])[0]
        line_shift = struct.unpack(">f", content[offset+6:offset+10])[0]
        corrections.append({
            "line_number": line_num,
            "column_shift": col_shift,
            "line_shift": line_shift
        })
        offset += 10

    result["corrections"] = corrections
    return result


def parse_obs_time_block(content: bytes) -> Dict[str, Any]:
    """Parse Block #9: Observation Time Information (variable)."""
    result = {}
    if len(content) < 7:
        return result

    offset = 0
    # Skip internal block header (1 byte block num + 2 bytes block len)
    offset += 3
    # 3: Number of observation times (2 bytes)
    result["num_obs_times"] = struct.unpack(">H", content[offset:offset+2])[0]
    offset += 2

    obs_times = []
    for _ in range(result.get("num_obs_times", 0)):
        if offset + 10 > len(content):
            break
        line_num = struct.unpack(">H", content[offset:offset+2])[0]
        obs_time = struct.unpack(">d", content[offset+2:offset+10])[0]
        obs_times.append({
            "line_number": line_num,
            "observation_time": obs_time
        })
        offset += 10

    result["observation_times"] = obs_times
    return result


def parse_error_block(content: bytes) -> Dict[str, Any]:
    """Parse Block #10: Error Information (variable)."""
    result = {}
    if len(content) < 8:
        return result

    offset = 0
    # Skip internal block header (1 byte block num + 2 bytes block len)
    offset += 3
    # 3: Number of error information data (2 bytes)
    result["num_errors"] = struct.unpack(">H", content[offset:offset+2])[0]
    offset += 2

    errors = []
    for _ in range(result.get("num_errors", 0)):
        if offset + 4 > len(content):
            break
        line_num = struct.unpack(">H", content[offset:offset+2])[0]
        error_pixels = struct.unpack(">H", content[offset+2:offset+4])[0]
        errors.append({
            "line_number": line_num,
            "error_pixels": error_pixels
        })
        offset += 4

    result["errors"] = errors
    return result


# Map block numbers to their parser functions
BLOCK_PARSERS = {
    BLOCK_BASIC_INFO: ("basic_info", parse_basic_info_block),
    BLOCK_DATA_INFO: ("data_info", parse_data_info_block),
    BLOCK_PROJECTION: ("projection", parse_projection_block),
    BLOCK_NAVIGATION: ("navigation", parse_navigation_block),
    BLOCK_CALIBRATION: ("calibration", parse_calibration_block),
    BLOCK_INTER_CALIBRATION: ("inter_calibration", parse_inter_calibration_block),
    BLOCK_SEGMENT: ("segment", parse_segment_block),
    BLOCK_NAV_CORRECTION: ("nav_correction", parse_nav_correction_block),
    BLOCK_OBS_TIME: ("obs_time", parse_obs_time_block),
    BLOCK_ERROR: ("error_info", parse_error_block),
    BLOCK_SPARE: ("spare", None),  # No need to parse spare
}


def parse_hsd_file(data: bytes) -> Tuple[np.ndarray, HSDHeaders]:
    """
    Parse a complete HSD file and extract pixel data.

    Args:
        data: Raw bytes of the HSD file (already decompressed if bz2)

    Returns:
        Tuple of (pixel_data_array, headers)
        pixel_data_array is a 2D numpy array of shape (lines, columns)
    """
    headers = HSDHeaders()
    raw_headers: Dict[int, Dict[str, Any]] = {}
    offset = 0
    data_block_offset = None
    data_block_length = None

    logger.info(f"Starting HSD parse, file size: {len(data)} bytes")

    while offset < len(data):
        if offset + 4 > len(data):
            logger.warning(f"Incomplete block header at offset {offset}")
            break

        # Read block header: block number (2 bytes) + block length (2 bytes)
        block_num = struct.unpack(">H", data[offset:offset+2])[0]
        block_len = struct.unpack(">H", data[offset+2:offset+4])[0]

        logger.debug(f"Block {block_num} at offset {offset}, length {block_len}")

        if block_len < 4:
            logger.error(f"Invalid block length {block_len} for block {block_num}")
            break

        # Extract block content (after the 4-byte header)
        block_content = data[offset+4:offset+block_len]

        if block_num == BLOCK_DATA:
            # Data block - save offset and break
            data_block_offset = offset + 4
            data_block_length = block_len - 4
            logger.info(f"Found data block at offset {data_block_offset}, length {data_block_length}")
            break
        elif block_num in BLOCK_PARSERS:
            field_name, parser = BLOCK_PARSERS[block_num]
            if parser:
                try:
                    parsed = parser(block_content)
                    raw_headers[block_num] = parsed
                    setattr(headers, field_name, parsed)
                    logger.debug(f"Parsed block {block_num}: {field_name}")
                except Exception as e:
                    logger.error(f"Error parsing block {block_num}: {e}")
                    raw_headers[block_num] = {}
            else:
                raw_headers[block_num] = {}
        else:
            logger.warning(f"Unknown block number: {block_num}")

        offset += block_len

    if data_block_offset is None:
        raise ValueError("No data block (block 12) found in HSD file")

    # Read pixel data using dimensions from Block 2
    nlines = headers.data_info.get("number_of_lines", 0)
    ncols = headers.data_info.get("number_of_columns", 0)
    bpp = headers.data_info.get("bits_per_pixel", 16)

    if nlines == 0 or ncols == 0:
        raise ValueError(f"Invalid dimensions: {nlines}x{ncols}")

    expected_size = nlines * ncols * 2  # 2 bytes per pixel (uint16)

    if data_block_length < expected_size:
        logger.warning(
            f"Data block smaller than expected: {data_block_length} < {expected_size}"
        )

    logger.info(f"Reading pixel data: {nlines}x{ncols}, {bpp} bpp")

    # Read as big-endian uint16
    pixels = np.frombuffer(
        data,
        dtype=">u2",
        offset=data_block_offset,
        count=nlines * ncols
    ).copy()

    # Reshape to 2D array
    image = pixels.reshape((nlines, ncols))

    # Convert to native byte order for processing
    image = image.astype(np.uint16)

    logger.info(f"Successfully parsed HSD file: {nlines}x{ncols} pixels")

    return image, headers


def read_bz2_file(filepath: str) -> bytes:
    """Read and decompress a bz2 file."""
    import bz2
    with open(filepath, 'rb') as f:
        compressed = f.read()
    return bz2.decompress(compressed)


def read_bz2_bytes(data: bytes) -> bytes:
    """Decompress bz2 data."""
    import bz2
    return bz2.decompress(data)
