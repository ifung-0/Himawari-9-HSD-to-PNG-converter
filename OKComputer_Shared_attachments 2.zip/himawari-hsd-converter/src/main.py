"""
Himawari-9 HSD to PNG Converter - FastAPI Application

Provides:
- Web UI for converting HSD files to PNG
- API endpoints for conversion and health checks
- Async downloading from S3 URLs with progress tracking
"""

import os
import io
import logging
import traceback
from pathlib import Path
from contextlib import asynccontextmanager

import httpx
import numpy as np
from PIL import Image
from fastapi import FastAPI, HTTPException, Query, Request
from fastapi.responses import HTMLResponse, StreamingResponse, Response
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from src.hsd_parser import parse_hsd_file, read_bz2_bytes
from src.renderer import create_png

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Constants
MAX_FILE_SIZE_MB = 500
MAX_FILE_SIZE_BYTES = MAX_FILE_SIZE_MB * 1024 * 1024
CHUNK_SIZE = 1024 * 1024  # 1MB chunks for streaming

# Get template directory
TEMPLATE_DIR = Path(__file__).parent / "templates"

# Setup templates
templates = Jinja2Templates(directory=str(TEMPLATE_DIR))


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan manager."""
    logger.info("Starting Himawari HSD Converter")
    yield
    logger.info("Shutting down Himawari HSD Converter")


app = FastAPI(
    title="Himawari-9 HSD to PNG Converter",
    description="Convert Himawari-9 satellite data (HSD format) to PNG images",
    version="1.0.0",
    lifespan=lifespan
)


@app.get("/health", response_class=Response)
async def health_check():
    """Health check endpoint."""
    return Response(
        content='{"status": "ok"}',
        media_type="application/json"
    )


@app.get("/", response_class=HTMLResponse)
async def index(request: Request):
    """Serve the main UI page."""
    template_path = TEMPLATE_DIR / "index.html"
    if template_path.exists():
        with open(template_path, 'r', encoding='utf-8') as f:
            content = f.read()
        return HTMLResponse(content=content)
    else:
        raise HTTPException(status_code=404, detail="Template not found")


@app.get("/convert")
async def convert_url(
    url: str = Query(..., description="S3 URL to .dat.bz2 file"),
    band: int = Query(None, description="Band number for metadata (optional)"),
    enhancement: str = Query("linear", description="Enhancement: linear, albedo, ir_color")
):
    """
    Convert a Himawari HSD file from URL to PNG.
    
    Query Parameters:
    - url: Full URL to .dat.bz2 file
    - band: Optional band number hint
    - enhancement: Enhancement type (linear, albedo, ir_color)
    
    Returns:
        PNG image with Content-Disposition for download
    """
    logger.info(f"Conversion request: url={url}, enhancement={enhancement}")
    
    # Validate URL
    if not url or not url.startswith(("http://", "https://")):
        raise HTTPException(status_code=400, detail="Invalid URL. Must be http:// or https://")
    
    if not url.endswith((".bz2", ".DAT", ".dat")):
        raise HTTPException(status_code=400, detail="URL must point to a .dat.bz2, .DAT, or .dat file")
    
    # Validate enhancement
    valid_enhancements = ["linear", "albedo", "ir_color", "ir_gray"]
    if enhancement not in valid_enhancements:
        raise HTTPException(
            status_code=400, 
            detail=f"Invalid enhancement. Must be one of: {', '.join(valid_enhancements)}"
        )
    
    try:
        # Download file with progress tracking
        logger.info(f"Downloading from: {url}")
        
        decompressed_data = await download_and_decompress(url)
        
        logger.info(f"Decompressed size: {len(decompressed_data)} bytes")
        
        # Parse HSD file
        logger.info("Parsing HSD file...")
        image_data, headers = parse_hsd_file(decompressed_data)
        
        band_num = headers.get_band_number()
        nlines, ncols = headers.get_dimensions()
        satellite = headers.get_satellite_name()
        area = headers.get_observation_area()
        filename = headers.get_file_name()
        
        logger.info(
            f"Parsed: {satellite} Band {band_num}, {nlines}x{ncols}, area={area}"
        )
        
        # Auto-detect enhancement if set to linear
        if enhancement == "linear":
            if 1 <= band_num <= 6:
                enhancement = "albedo"
            elif 7 <= band_num <= 16:
                enhancement = "ir_color"
        
        # Generate output filename
        if filename:
            base_name = filename.replace(".DAT", "").replace(".dat", "")
            output_filename = f"{base_name}_{enhancement}.png"
        else:
            output_filename = f"himawari_band{band_num}_{enhancement}.png"
        
        # Create PNG
        logger.info(f"Creating PNG with enhancement '{enhancement}'...")
        png_bytes = create_png(image_data, headers, enhancement)
        
        logger.info(f"PNG created: {len(png_bytes)} bytes")
        
        # Return as downloadable response
        return StreamingResponse(
            io.BytesIO(png_bytes),
            media_type="image/png",
            headers={
                "Content-Disposition": f'attachment; filename="{output_filename}"'
            }
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Conversion error: {e}")
        logger.error(traceback.format_exc())
        raise HTTPException(status_code=500, detail=f"Processing error: {str(e)}")


async def download_and_decompress(url: str) -> bytes:
    """
    Download a file from URL and decompress if bz2.
    
    Args:
        url: URL to download from
    
    Returns:
        Decompressed file data
    """
    downloaded_size = 0
    chunks = []
    
    try:
        async with httpx.AsyncClient(timeout=300.0, follow_redirects=True) as client:
            async with client.stream("GET", url) as response:
                # Check status
                if response.status_code == 404:
                    raise HTTPException(status_code=404, detail="File not found on server")
                elif response.status_code == 403:
                    raise HTTPException(status_code=403, detail="Access denied to file")
                elif response.status_code >= 400:
                    raise HTTPException(
                        status_code=400, 
                        detail=f"Download failed with status {response.status_code}"
                    )
                
                # Check content length
                content_length = response.headers.get("content-length")
                if content_length:
                    total_size = int(content_length)
                    if total_size > MAX_FILE_SIZE_BYTES:
                        raise HTTPException(
                            status_code=413, 
                            detail=f"File too large: {total_size / 1024 / 1024:.1f}MB (max {MAX_FILE_SIZE_MB}MB)"
                        )
                    logger.info(f"Content-Length: {total_size / 1024 / 1024:.1f}MB")
                
                # Stream download
                async for chunk in response.aiter_bytes(chunk_size=CHUNK_SIZE):
                    downloaded_size += len(chunk)
                    chunks.append(chunk)
                    
                    # Check size limit
                    if downloaded_size > MAX_FILE_SIZE_BYTES:
                        raise HTTPException(
                            status_code=413,
                            detail=f"File exceeds maximum size of {MAX_FILE_SIZE_MB}MB"
                        )
                    
                    if downloaded_size % (10 * CHUNK_SIZE) == 0:
                        logger.info(f"Downloaded: {downloaded_size / 1024 / 1024:.1f}MB")
        
        logger.info(f"Download complete: {downloaded_size / 1024 / 1024:.1f}MB")
        
        # Combine chunks
        file_data = b"".join(chunks)
        
        # Decompress if bz2
        if url.endswith(".bz2"):
            logger.info("Decompressing bz2 data...")
            try:
                decompressed = read_bz2_bytes(file_data)
                logger.info(f"Decompressed: {len(decompressed)} bytes")
                return decompressed
            except Exception as e:
                raise HTTPException(status_code=400, detail=f"Failed to decompress bz2: {str(e)}")
        else:
            return file_data
            
    except HTTPException:
        raise
    except httpx.TimeoutException:
        raise HTTPException(status_code=504, detail="Download timeout")
    except httpx.ConnectError:
        raise HTTPException(status_code=502, detail="Cannot connect to server")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Download failed: {str(e)}")


@app.get("/api/info")
async def get_info(url: str = Query(..., description="S3 URL to .dat.bz2 file")):
    """
    Get metadata information about an HSD file without converting.
    
    Returns JSON with satellite info, band, dimensions, timestamps, etc.
    """
    logger.info(f"Info request: {url}")
    
    if not url or not url.startswith(("http://", "https://")):
        raise HTTPException(status_code=400, detail="Invalid URL")
    
    try:
        decompressed_data = await download_and_decompress(url)
        image_data, headers = parse_hsd_file(decompressed_data)
        
        # Build response
        info = {
            "satellite": headers.get_satellite_name(),
            "band_number": headers.get_band_number(),
            "observation_area": headers.get_observation_area(),
            "file_name": headers.get_file_name(),
            "dimensions": {
                "lines": headers.data_info.get("number_of_lines", 0),
                "columns": headers.data_info.get("number_of_columns", 0),
            },
            "bits_per_pixel": headers.data_info.get("bits_per_pixel", 0),
            "compression": headers.data_info.get("compression_flag", 0),
            "central_wavelength_um": headers.calibration.get("central_wavelength", 0),
            "observation_timeline": headers.basic_info.get("observation_timeline", 0),
            "file_format_version": headers.basic_info.get("file_format_version", ""),
            "calibration": {
                "slope": headers.calibration.get("slope", 0),
                "intercept": headers.calibration.get("intercept", 0),
            }
        }
        
        return info
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Info error: {e}")
        raise HTTPException(status_code=500, detail=f"Processing error: {str(e)}")


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
