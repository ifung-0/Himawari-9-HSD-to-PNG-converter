"""
Calibration functions for Himawari HSD data.

Visible/NIR bands (1-6): Convert counts to albedo (%)
IR bands (7-16): Convert counts to brightness temperature (K)
"""

import logging
import numpy as np
from src.hsd_parser import HSDHeaders

logger = logging.getLogger(__name__)


def counts_to_radiance(counts: np.ndarray, slope: float, intercept: float) -> np.ndarray:
    """
    Convert raw counts to radiance.
    
    Formula: Radiance = Slope * Count + Intercept
    
    Args:
        counts: Raw pixel counts (uint16 array)
        slope: Calibration slope
        intercept: Calibration intercept
    
    Returns:
        Radiance values as float64 array
    """
    counts_float = counts.astype(np.float64)
    radiance = slope * counts_float + intercept
    return radiance


def radiance_to_albedo(radiance: np.ndarray, c_prime: float) -> np.ndarray:
    """
    Convert radiance to albedo (reflectance) for visible/NIR bands.
    
    Formula: Albedo = c' * Radiance
    where c' is the transformation coefficient from radiance to albedo.
    
    For reference: A = π * I / S0 (I=radiance, S0=band solar irradiance)
    
    Args:
        radiance: Radiance values
        c_prime: Transformation coefficient
    
    Returns:
        Albedo values (0-1 range typically)
    """
    albedo = c_prime * radiance
    # Clip negative values
    albedo = np.clip(albedo, 0, None)
    return albedo


def counts_to_albedo_visible(counts: np.ndarray, slope: float, intercept: float, c_prime: float) -> np.ndarray:
    """
    Convert raw counts directly to albedo for visible/NIR bands.
    
    Combined: Albedo = c' * (Slope * Count + Intercept)
    
    Args:
        counts: Raw pixel counts
        slope: Calibration slope
        intercept: Calibration intercept
        c_prime: Radiance to albedo coefficient
    
    Returns:
        Albedo values as float64 array
    """
    radiance = counts_to_radiance(counts, slope, intercept)
    albedo = radiance_to_albedo(radiance, c_prime)
    return albedo


def radiance_to_brightness_temp(radiance: np.ndarray, c0: float, c1: float, c2: float,
                                 central_wavelength: float) -> np.ndarray:
    """
    Convert radiance to brightness temperature for IR bands.
    
    Uses the inverse Planck function with sensor-specific coefficients.
    
    Formula:
        Te = c0 + c1 * ν + c2 * ν²  (effective temperature)
        Tb = Te  (brightness temperature, for IR bands with c2=0)
    
    where ν = c / λ is the wavenumber
    
    For simpler cases (when c2=0):
        Tb = (h*c/k) / (λ * ln(2*h*c²/(I*λ⁵) + 1))
    
    But we'll use the sensor-provided coefficients:
        Tb = c0 + c1 * ln(I) + c2 * (ln(I))²
    
    Actually, for Himawari the standard approach is:
        Te = {c1 * ν / ln(c2 * ν³ / I + 1)} / c0
    
    Let's use the coefficients from the header directly.
    
    Args:
        radiance: Radiance values in W/(m² sr μm)
        c0, c1, c2: Planck function coefficients from calibration block
        central_wavelength: Band central wavelength in μm
    
    Returns:
        Brightness temperature in Kelvin as float64 array
    """
    # Avoid log of zero/negative
    radiance_safe = np.clip(radiance, 1e-10, None)
    
    # Using the formula from JMA specification:
    # For IR bands with the c0, c1, c2 coefficients:
    # The exact formula depends on the specific sensor calibration
    
    # Common approach for Himawari:
    # Te = c0 + c1 * wavenumber + c2 * wavenumber^2
    # But actually the standard Planck inversion is:
    
    # h = 6.62607015e-34  # Planck constant (J·s)
    # c = 2.99792458e8    # Speed of light (m/s)
    # k = 1.380649e-23    # Boltzmann constant (J/K)
    
    # Convert wavelength to meters
    wavelength_m = central_wavelength * 1e-6
    
    # Using inverse Planck function:
    # I = (2*h*c²/λ⁵) / (exp(h*c/(k*λ*T)) - 1)
    # Solve for T:
    # T = (h*c/(k*λ)) / ln(2*h*c²/(I*λ⁵) + 1)
    
    h = 6.62607015e-34
    c = 2.99792458e8
    k = 1.380649e-23
    
    c1_const = h * c / k  # = 0.01438776877 m·K
    c2_const = 2 * h * c**2  # Radiance constant
    
    # Convert radiance from W/(m² sr μm) to W/(m² sr m)
    radiance_si = radiance_safe * 1e6  # per meter instead of per micrometer
    
    # Planck inversion
    exponent = (c2_const / (wavelength_m**5 * radiance_si)) + 1.0
    exponent = np.clip(exponent, 1.0 + 1e-10, None)  # ensure > 1 for log
    
    bt = c1_const / (wavelength_m * np.log(exponent))
    
    # Apply sensor-specific correction if coefficients are valid
    if c0 != 0 and c1 != 0:
        # Alternative: use the provided coefficients
        # Some implementations use: bt_corrected = c0 + c1 * bt + c2 * bt^2
        pass  # The Planck calculation above is standard
    
    return bt


def calibrate_pixels(image: np.ndarray, headers: HSDHeaders) -> np.ndarray:
    """
    Calibrate raw pixel counts to physical values.
    
    For visible/NIR bands (1-6): returns albedo (0-100%)
    For IR bands (7-16): returns brightness temperature (K)
    
    Args:
        image: Raw pixel counts (2D uint16 array)
        headers: Parsed HSD headers with calibration info
    
    Returns:
        Calibrated values as float64 array
    """
    band_num = headers.get_band_number()
    cal = headers.calibration
    
    logger.info(f"Calibrating band {band_num} data")
    
    # Get calibration coefficients
    slope = cal.get("slope", 1.0)
    intercept = cal.get("intercept", 0.0)
    
    # Handle special pixel values
    error_count = cal.get("error_pixel_count", 65535)
    outside_count = cal.get("outside_scan_count", 65534)
    
    # Create mask for valid pixels
    valid_mask = (image != error_count) & (image != outside_count) & (image != 0)
    
    # Initialize output array
    calibrated = np.full_like(image, np.nan, dtype=np.float64)
    
    if 1 <= band_num <= 6:
        # Visible/NIR band - convert to albedo
        c_prime = cal.get("c_prime", 1.0)
        
        logger.info(f"Visible band {band_num}: slope={slope}, intercept={intercept}, c'={c_prime}")
        
        # Only calibrate valid pixels
        valid_counts = image[valid_mask]
        albedo = counts_to_albedo_visible(valid_counts, slope, intercept, c_prime)
        
        # Clip albedo to reasonable range [0, 1.5] (can exceed 100% for specular reflection)
        albedo = np.clip(albedo, 0.0, 1.5)
        
        calibrated[valid_mask] = albedo
        
    elif 7 <= band_num <= 16:
        # IR band - convert to brightness temperature
        c0 = cal.get("c0", 0.0)
        c1_coeff = cal.get("c1", 1.0)
        c2_coeff = cal.get("c2", 0.0)
        central_wavelength = cal.get("central_wavelength", 10.0)
        
        logger.info(
            f"IR band {band_num}: slope={slope}, intercept={intercept}, "
            f"c0={c0}, c1={c1_coeff}, c2={c2_coeff}, wavelength={central_wavelength}μm"
        )
        
        # Convert counts to radiance
        valid_counts = image[valid_mask]
        radiance = counts_to_radiance(valid_counts, slope, intercept)
        
        # Convert radiance to brightness temperature
        bt = radiance_to_brightness_temp(radiance, c0, c1_coeff, c2_coeff, central_wavelength)
        
        # Clip BT to reasonable range [150, 400] K
        bt = np.clip(bt, 150.0, 400.0)
        
        calibrated[valid_mask] = bt
        
    else:
        logger.warning(f"Unknown band {band_num}, returning raw counts")
        calibrated = image.astype(np.float64)
    
    return calibrated
