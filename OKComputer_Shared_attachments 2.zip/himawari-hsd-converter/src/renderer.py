"""
Image rendering module for Himawari HSD data.

Provides various enhancement methods for visualizing satellite data:
- Linear stretch (grayscale)
- Albedo scaling (for visible bands)
- IR color tables (for infrared bands)
"""

import logging
import numpy as np
from PIL import Image
from src.hsd_parser import HSDHeaders
from src.calibration import calibrate_pixels

logger = logging.getLogger(__name__)


def apply_valid_mask(image: np.ndarray, headers: HSDHeaders) -> np.ndarray:
    """
    Create a mask of valid (non-fill) pixels.
    
    Returns:
        Boolean mask where True = valid pixel
    """
    cal = headers.calibration
    error_count = cal.get("error_pixel_count", 65535)
    outside_count = cal.get("outside_scan_count", 65534)
    
    mask = (image != error_count) & (image != outside_count) & (image != 0)
    return mask


def linear_stretch(calibrated: np.ndarray, mask: np.ndarray,
                   low_percentile: float = 1.0, high_percentile: float = 99.0) -> np.ndarray:
    """
    Apply linear contrast stretch based on percentiles.
    
    Maps data from [low, high] to [0, 255].
    
    Args:
        calibrated: Calibrated pixel values (float64)
        mask: Valid pixel mask
        low_percentile: Lower percentile for stretch
        high_percentile: Upper percentile for stretch
    
    Returns:
        8-bit grayscale image array
    """
    valid_data = calibrated[mask]
    
    if len(valid_data) == 0:
        return np.zeros_like(calibrated, dtype=np.uint8)
    
    low = np.percentile(valid_data, low_percentile)
    high = np.percentile(valid_data, high_percentile)
    
    if high <= low:
        high = low + 1.0
    
    # Normalize to 0-255
    stretched = (calibrated - low) / (high - low) * 255.0
    stretched = np.clip(stretched, 0, 255)
    
    result = np.zeros_like(calibrated, dtype=np.uint8)
    result[mask] = stretched[mask].astype(np.uint8)
    
    return result


def min_max_stretch(calibrated: np.ndarray, mask: np.ndarray) -> np.ndarray:
    """
    Apply min-max linear stretch.
    
    Maps data from [min, max] to [0, 255].
    """
    valid_data = calibrated[mask]
    
    if len(valid_data) == 0:
        return np.zeros_like(calibrated, dtype=np.uint8)
    
    data_min = np.min(valid_data)
    data_max = np.max(valid_data)
    
    if data_max <= data_min:
        data_max = data_min + 1.0
    
    stretched = (calibrated - data_min) / (data_max - data_min) * 255.0
    stretched = np.clip(stretched, 0, 255)
    
    result = np.zeros_like(calibrated, dtype=np.uint8)
    result[mask] = stretched[mask].astype(np.uint8)
    
    return result


def create_ir_color_table() -> np.ndarray:
    """
    Create a color lookup table for IR brightness temperatures.
    
    Maps temperature to RGB colors (similar to meteorological color enhancement).
    
    Returns:
        uint8 array of shape (256, 3) for R, G, B
    """
    lut = np.zeros((256, 3), dtype=np.uint8)
    
    # Temperature ranges and colors (approximate meteorological standard)
    # Values are scaled from 0-255 where 0 = coldest, 255 = warmest
    
    # Create a smooth gradient from cold (purple/blue) to warm (red/yellow)
    for i in range(256):
        t = i / 255.0  # Normalized temperature (0=cold, 1=warm)
        
        if t < 0.15:  # Very cold - deep purple/blue
            r = int(20 + t / 0.15 * 50)
            g = 0
            b = int(150 + t / 0.15 * 105)
        elif t < 0.3:  # Cold - blue to cyan
            r = 0
            g = int((t - 0.15) / 0.15 * 150)
            b = 255
        elif t < 0.45:  # Cool - cyan to green
            r = 0
            g = 150 + int((t - 0.3) / 0.15 * 105)
            b = int(255 - (t - 0.3) / 0.15 * 255)
        elif t < 0.6:  # Moderate - green to yellow
            r = int((t - 0.45) / 0.15 * 255)
            g = 255
            b = 0
        elif t < 0.75:  # Warm - yellow to orange
            r = 255
            g = int(255 - (t - 0.6) / 0.15 * 100)
            b = 0
        else:  # Very warm - orange to red to white
            if t < 0.9:
                r = 255
                g = int(155 - (t - 0.75) / 0.15 * 155)
                b = 0
            else:
                r = 255
                g = int((t - 0.9) / 0.1 * 255)
                b = int((t - 0.9) / 0.1 * 255)
        
        lut[i] = [r, g, b]
    
    return lut


def create_ir_grayscale_table() -> np.ndarray:
    """Create grayscale lookup table for IR (inverted: cold=white, warm=black)."""
    lut = np.zeros((256, 3), dtype=np.uint8)
    for i in range(256):
        v = 255 - i  # Inverted - cold = white
        lut[i] = [v, v, v]
    return lut


def create_ir_rainbow_table() -> np.ndarray:
    """
    Create a rainbow color table for IR data.
    
    Standard meteorological rainbow enhancement.
    """
    lut = np.zeros((256, 3), dtype=np.uint8)
    
    for i in range(256):
        t = i / 255.0
        
        # Rainbow: violet -> blue -> green -> yellow -> orange -> red
        if t < 0.16:  # Violet to blue
            r = int(148 - t / 0.16 * 148)
            g = 0
            b = int(211 - t / 0.16 * (211 - 255))
        elif t < 0.33:  # Blue to cyan
            r = 0
            g = int((t - 0.16) / 0.17 * 255)
            b = 255
        elif t < 0.5:  # Cyan to green
            r = 0
            g = 255
            b = int(255 - (t - 0.33) / 0.17 * 255)
        elif t < 0.66:  # Green to yellow
            r = int((t - 0.5) / 0.16 * 255)
            g = 255
            b = 0
        elif t < 0.83:  # Yellow to orange
            r = 255
            g = int(255 - (t - 0.66) / 0.17 * 100)
            b = 0
        else:  # Orange to red
            r = 255
            g = int(155 - (t - 0.83) / 0.17 * 155)
            b = 0
        
        lut[i] = [r, g, b]
    
    return lut


def apply_color_table(stretched: np.ndarray, color_table: np.ndarray) -> np.ndarray:
    """
    Apply a color lookup table to grayscale values.
    
    Args:
        stretched: 8-bit grayscale image
        color_table: (256, 3) uint8 RGB lookup table
    
    Returns:
        RGB image array of shape (H, W, 3)
    """
    h, w = stretched.shape
    rgb = np.zeros((h, w, 3), dtype=np.uint8)
    rgb[:, :, 0] = color_table[stretched, 0]
    rgb[:, :, 1] = color_table[stretched, 1]
    rgb[:, :, 2] = color_table[stretched, 2]
    return rgb


def render_visible_band(image: np.ndarray, headers: HSDHeaders,
                        enhancement: str = "albedo") -> np.ndarray:
    """
    Render a visible/NIR band to an RGB image.
    
    Args:
        image: Raw pixel counts
        headers: HSD headers
        enhancement: 'albedo' for reflectance scaling, 'linear' for simple stretch
    
    Returns:
        RGB uint8 image array
    """
    mask = apply_valid_mask(image, headers)
    
    if enhancement == "albedo":
        # Calibrate to albedo
        calibrated = calibrate_pixels(image, headers)
        # Albedo is typically 0-1, scale to 0-255
        # Use percentile stretch for better visualization
        grayscale = linear_stretch(calibrated, mask, 0.5, 99.5)
    else:
        # Simple linear stretch of raw counts
        grayscale = linear_stretch(image.astype(np.float64), mask)
    
    # Convert grayscale to RGB
    rgb = np.stack([grayscale, grayscale, grayscale], axis=-1)
    
    return rgb


def render_ir_band(image: np.ndarray, headers: HSDHeaders,
                   enhancement: str = "ir_color") -> np.ndarray:
    """
    Render an IR band to an RGB image with color enhancement.
    
    Args:
        image: Raw pixel counts
        headers: HSD headers
        enhancement: 'ir_color' for color-enhanced, 'linear' for grayscale
    
    Returns:
        RGB uint8 image array
    """
    mask = apply_valid_mask(image, headers)
    
    # Calibrate to brightness temperature
    calibrated = calibrate_pixels(image, headers)
    
    if enhancement == "ir_color":
        # Use color table (cold = bright colors, warm = dark)
        # BT typically ranges from ~200K (cold clouds) to ~300K (warm surface)
        # We need to map this to 0-255
        grayscale = linear_stretch(calibrated, mask, 1.0, 99.0)
        color_table = create_ir_color_table()
        rgb = apply_color_table(grayscale, color_table)
    elif enhancement == "ir_gray":
        # Inverted grayscale (cold = white, warm = black)
        grayscale = linear_stretch(calibrated, mask, 1.0, 99.0)
        color_table = create_ir_grayscale_table()
        rgb = apply_color_table(grayscale, color_table)
    else:
        # Simple linear stretch
        grayscale = linear_stretch(calibrated, mask)
        rgb = np.stack([grayscale, grayscale, grayscale], axis=-1)
    
    return rgb


def render_image(image: np.ndarray, headers: HSDHeaders,
                 enhancement: str = "linear") -> np.ndarray:
    """
    Render HSD image data to RGB based on band and enhancement type.
    
    Args:
        image: Raw pixel counts (2D uint16 array)
        headers: Parsed HSD headers
        enhancement: One of 'linear', 'albedo', 'ir_color', 'ir_gray'
    
    Returns:
        RGB uint8 image array of shape (H, W, 3)
    """
    band_num = headers.get_band_number()
    
    logger.info(f"Rendering band {band_num} with enhancement '{enhancement}'")
    
    if enhancement == "linear":
        # Simple linear stretch for any band
        mask = apply_valid_mask(image, headers)
        grayscale = linear_stretch(image.astype(np.float64), mask)
        rgb = np.stack([grayscale, grayscale, grayscale], axis=-1)
        return rgb
    
    if 1 <= band_num <= 6:
        # Visible/NIR band
        return render_visible_band(image, headers, enhancement)
    elif 7 <= band_num <= 16:
        # IR band
        return render_ir_band(image, headers, enhancement)
    else:
        # Unknown band - use linear stretch
        logger.warning(f"Unknown band {band_num}, using linear stretch")
        mask = apply_valid_mask(image, headers)
        grayscale = linear_stretch(image.astype(np.float64), mask)
        rgb = np.stack([grayscale, grayscale, grayscale], axis=-1)
        return rgb


def create_png(image_data: np.ndarray, headers: HSDHeaders,
               enhancement: str = "linear") -> bytes:
    """
    Create a PNG image from HSD data.
    
    Args:
        image_data: Raw pixel counts from HSD file
        headers: Parsed HSD headers
        enhancement: Enhancement type
    
    Returns:
        PNG image as bytes
    """
    # Render to RGB
    rgb_image = render_image(image_data, headers, enhancement)
    
    # Create PIL Image
    img = Image.fromarray(rgb_image, mode='RGB')
    
    # Save to bytes
    import io
    buf = io.BytesIO()
    img.save(buf, format='PNG', optimize=True)
    png_bytes = buf.getvalue()
    
    logger.info(f"Created PNG: {img.size}, {len(png_bytes)} bytes")
    
    return png_bytes
