"""
Unit tests for the HSD parser.

Tests parsing of mock HSD binary data and validates the parser
handles all block types correctly.
"""

import struct
import pytest
import numpy as np
from src.hsd_parser import (
    parse_hsd_file,
    parse_basic_info_block,
    parse_data_info_block,
    parse_projection_block,
    parse_calibration_block,
    parse_segment_block,
    HSDHeaders,
)


def create_mock_basic_info_block() -> bytes:
    """Create a mock basic information block (block 1).
    
    Returns block CONTENT only (without the 4-byte block header).
    The main parser adds the 4-byte header (block_num + block_length) separately.
    """
    data = bytearray()
    # 1: Header block number (1 byte) - 1
    data.append(1)
    # 2: Block length (2 bytes) - 282 (total including header)
    data.extend(struct.pack(">H", 282))
    # 3: Total number of header blocks (2 bytes)
    data.extend(struct.pack(">H", 11))
    # 4: Byte order (1 byte) - 1 = big endian
    data.append(1)
    # 5: Satellite name (16 bytes) - padded with nulls
    name = b"Himawari-9"
    data.extend(name + b"\x00" * (16 - len(name)))
    # 6: Processing center (16 bytes)
    center = b"MSC"
    data.extend(center + b"\x00" * (16 - len(center)))
    # 7: Observation area (4 bytes)
    data.extend(b"FLDK")
    # 8: Other observation info (2 bytes)
    data.extend(b"\x00\x00")
    # 9: Observation timeline (2 bytes) - 0400
    data.extend(struct.pack(">H", 400))
    # 10: Observation start time (8 bytes double - MJD)
    data.extend(struct.pack(">d", 60600.0))
    # 11: Observation end time (8 bytes double)
    data.extend(struct.pack(">d", 60600.006944))
    # 12: File creation time (8 bytes double)
    data.extend(struct.pack(">d", 60600.01))
    # 13: Total header length (4 bytes)
    data.extend(struct.pack(">I", 1800))
    # 14: Total data length (4 bytes)
    data.extend(struct.pack(">I", 242000000))
    # 15: Spare (40 bytes)
    data.extend(b"\x00" * 40)
    # 16-19: Quality flags (4 bytes)
    data.extend(b"\x00\x00\x00\x00")
    # 20: File format version (32 bytes)
    version = b"1.3"
    data.extend(version + b"\x00" * (32 - len(version)))
    # 21: File name (128 bytes)
    filename = b"HS_H09_20260404_0400_B01_FLDK_R10_S1010.DAT"
    data.extend(filename + b"\x00" * (128 - len(filename)))
    # 22: Spare (40 bytes)
    data.extend(b"\x00" * 40)
    
    return bytes(data)


def create_mock_data_info_block(nlines: int = 1100, ncols: int = 1100) -> bytes:
    """Create a mock data information block (block 2).
    
    Returns block CONTENT only (without the 4-byte block header).
    """
    data = bytearray()
    # 1: Header block number (1 byte)
    data.append(2)
    # 2: Block length (2 bytes) - 50
    data.extend(struct.pack(">H", 50))
    # 3: Number of bits per pixel (2 bytes)
    data.extend(struct.pack(">H", 16))
    # 4: Number of columns (2 bytes)
    data.extend(struct.pack(">H", ncols))
    # 5: Number of lines (2 bytes)
    data.extend(struct.pack(">H", nlines))
    # 6: Compression flag (1 byte) - 0 = none
    data.append(0)
    # 7: Spare (40 bytes)
    data.extend(b"\x00" * 40)
    
    return bytes(data)


def create_mock_projection_block() -> bytes:
    """Create a mock projection information block (block 3).
    
    Returns block CONTENT only (without the 4-byte block header).
    """
    data = bytearray()
    # 1: Header block number (1 byte)
    data.append(3)
    # 2: Block length (2 bytes) - 127
    data.extend(struct.pack(">H", 127))
    # 3: sub_lon (8 bytes double)
    data.extend(struct.pack(">d", 140.7))
    # 4: CFAC (4 bytes uint32)
    data.extend(struct.pack(">I", 40932549))
    # 5: LFAC (4 bytes uint32)
    data.extend(struct.pack(">I", 40932549))
    # 6: COFF (4 bytes float)
    data.extend(struct.pack(">f", 5500.5))
    # 7: LOFF (4 bytes float)
    data.extend(struct.pack(">f", 5500.5))
    # 8: Distance (8 bytes double)
    data.extend(struct.pack(">d", 42164.0))
    # 9: Equatorial radius (8 bytes double)
    data.extend(struct.pack(">d", 6378.137))
    # 10: Polar radius (8 bytes double)
    data.extend(struct.pack(">d", 6356.7523))
    # 11-14: Various coefficients (8*4 = 32 bytes)
    data.extend(struct.pack(">d", 0.00669438444))
    data.extend(struct.pack(">d", 0.993305616))
    data.extend(struct.pack(">d", 1.006739501))
    data.extend(struct.pack(">d", 1737122264.0))
    # 15-16: Resampling (4 bytes)
    data.extend(struct.pack(">H", 0))
    data.extend(struct.pack(">H", 0))
    # 17: Spare (40 bytes)
    data.extend(b"\x00" * 40)
    
    return bytes(data)


def create_mock_calibration_block_visible() -> bytes:
    """Create a mock calibration block for visible band (block 5).
    
    Returns block CONTENT only (without the 4-byte block header).
    """
    data = bytearray()
    # 1: Header block number (1 byte)
    data.append(5)
    # 2: Block length (2 bytes) - 147
    data.extend(struct.pack(">H", 147))
    # 3: Band number (2 bytes) - 1
    data.extend(struct.pack(">H", 1))
    # 4: Central wavelength (8 bytes double)
    data.extend(struct.pack(">d", 0.47))
    # 5: Valid bits per pixel (2 bytes)
    data.extend(struct.pack(">H", 11))
    # 6: Error pixel count (2 bytes)
    data.extend(struct.pack(">H", 65535))
    # 7: Outside scan count (2 bytes)
    data.extend(struct.pack(">H", 65534))
    # Visible band fields
    # 8: Slope (8 bytes double)
    data.extend(struct.pack(">d", 0.001))
    # 9: Intercept (8 bytes double)
    data.extend(struct.pack(">d", 0.0))
    # 10: c_prime (8 bytes double)
    data.extend(struct.pack(">d", 100.0))
    # 11: Update time (8 bytes double)
    data.extend(struct.pack(">d", 60600.0))
    # 12: Updated slope (8 bytes double)
    data.extend(struct.pack(">d", 0.001))
    # 13: Updated intercept (8 bytes double)
    data.extend(struct.pack(">d", 0.0))
    # 14-18: Spare (8*5 = 40 bytes)
    data.extend(b"\x00" * 40)
    # 19: Spare (40 bytes)
    data.extend(b"\x00" * 40)
    
    return bytes(data)


def create_mock_calibration_block_ir() -> bytes:
    """Create a mock calibration block for IR band (block 5).
    
    Returns block CONTENT only (without the 4-byte block header).
    """
    data = bytearray()
    # 1: Header block number (1 byte)
    data.append(5)
    # 2: Block length (2 bytes) - 147
    data.extend(struct.pack(">H", 147))
    # 3: Band number (2 bytes) - 13
    data.extend(struct.pack(">H", 13))
    # 4: Central wavelength (8 bytes double)
    data.extend(struct.pack(">d", 10.4))
    # 5: Valid bits per pixel (2 bytes)
    data.extend(struct.pack(">H", 12))
    # 6: Error pixel count (2 bytes)
    data.extend(struct.pack(">H", 65535))
    # 7: Outside scan count (2 bytes)
    data.extend(struct.pack(">H", 65534))
    # IR band fields
    # 8: Slope (8 bytes double)
    data.extend(struct.pack(">d", 0.1))
    # 9: Intercept (8 bytes double)
    data.extend(struct.pack(">d", -5.0))
    # 10: c0 (8 bytes double)
    data.extend(struct.pack(">d", 0.0))
    # 11: c1 (8 bytes double)
    data.extend(struct.pack(">d", 1.0))
    # 12: c2 (8 bytes double)
    data.extend(struct.pack(">d", 0.0))
    # 13: C0 (8 bytes double)
    data.extend(struct.pack(">d", 273.15))
    # 14: C1 (8 bytes double)
    data.extend(struct.pack(">d", 1.0))
    # 15: C2 (8 bytes double)
    data.extend(struct.pack(">d", 0.0))
    # 16: Speed of light (8 bytes double)
    data.extend(struct.pack(">d", 2.99792458e8))
    # 17: Planck constant (8 bytes double)
    data.extend(struct.pack(">d", 6.62607015e-34))
    # 18: Boltzmann constant (8 bytes double)
    data.extend(struct.pack(">d", 1.380649e-23))
    # 19: Spare (40 bytes)
    data.extend(b"\x00" * 40)
    
    return bytes(data)


def create_mock_segment_block() -> bytes:
    """Create a mock segment information block (block 7)."""
    data = bytearray()
    # 1: Header block number (1 byte)
    data.append(7)
    # 2: Block length (2 bytes) - 47
    data.extend(struct.pack(">H", 47))
    # 3: Total segments (1 byte)
    data.append(1)
    # 4: Segment number (1 byte)
    data.append(1)
    # 5: First line number (2 bytes)
    data.extend(struct.pack(">H", 1))
    # 6: Spare (40 bytes)
    data.extend(b"\x00" * 40)
    
    return bytes(data)


def create_mock_hsd_file(nlines: int = 50, ncols: int = 50, band: int = 1) -> bytes:
    """
    Create a complete mock HSD file with synthetic pixel data.
    
    Args:
        nlines: Number of lines in image
        ncols: Number of columns in image
        band: Band number (1-6=visible, 7-16=IR)
    
    Returns:
        Complete mock HSD file as bytes
    """
    file_data = bytearray()
    
    def add_block(block_num: int, block_content: bytes):
        """Helper to add a block with proper 4-byte external header."""
        total_len = 4 + len(block_content)
        file_data.extend(struct.pack(">H", block_num))  # 2 bytes block number
        file_data.extend(struct.pack(">H", total_len))   # 2 bytes block length
        file_data.extend(block_content)
    
    # Block 1: Basic Information
    add_block(1, create_mock_basic_info_block())
    
    # Block 2: Data Information
    add_block(2, create_mock_data_info_block(nlines, ncols))
    
    # Block 3: Projection Information
    add_block(3, create_mock_projection_block())
    
    # Block 4: Navigation Information (simplified)
    nav_content = bytearray()
    nav_content.append(4)
    nav_content.extend(struct.pack(">H", 139))
    nav_content.extend(b"\x00" * 135)
    add_block(4, bytes(nav_content))
    
    # Block 5: Calibration Information
    if 1 <= band <= 6:
        add_block(5, create_mock_calibration_block_visible())
    else:
        add_block(5, create_mock_calibration_block_ir())
    
    # Block 6: Inter-calibration (simplified)
    inter_cal = bytearray()
    inter_cal.append(6)
    inter_cal.extend(struct.pack(">H", 259))
    inter_cal.extend(b"\x00" * 255)
    add_block(6, bytes(inter_cal))
    
    # Block 7: Segment Information
    add_block(7, create_mock_segment_block())
    
    # Blocks 8-11: simplified (just fill)
    for block_num in [8, 9, 10, 11]:
        content_len = 96 if block_num != 11 else 255
        block_content = bytearray()
        block_content.append(block_num)
        block_content.extend(struct.pack(">H", content_len + 4))
        block_content.extend(b"\x00" * (content_len - 3))
        add_block(block_num, bytes(block_content))
    
    # Block 12: Data Block
    pixel_data_size = nlines * ncols * 2  # uint16 per pixel
    data_block_len = 4 + pixel_data_size
    add_block(12, b"")  # data block has no content, data follows
    
    # Generate synthetic pixel data (gradient pattern for testing)
    for i in range(nlines):
        for j in range(ncols):
            # Create a gradient pattern
            value = int((i / nlines) * 65535 * 0.5 + (j / ncols) * 65535 * 0.5) % 65535
            if value == 0:
                value = 1  # Avoid fill values
            file_data.extend(struct.pack(">H", value))
    
    return bytes(file_data)


class TestBasicInfoBlock:
    """Tests for basic information block parser."""
    
    def test_satellite_name(self):
        block = create_mock_basic_info_block()
        result = parse_basic_info_block(block)
        assert result["satellite_name"] == "Himawari-9"
    
    def test_observation_area(self):
        block = create_mock_basic_info_block()
        result = parse_basic_info_block(block)
        assert result["observation_area"] == "FLDK"
    
    def test_total_header_blocks(self):
        block = create_mock_basic_info_block()
        result = parse_basic_info_block(block)
        assert result["total_header_blocks"] == 11
    
    def test_byte_order(self):
        block = create_mock_basic_info_block()
        result = parse_basic_info_block(block)
        assert result["byte_order"] == 1  # big endian


class TestDataInfoBlock:
    """Tests for data information block parser."""
    
    def test_bits_per_pixel(self):
        block = create_mock_data_info_block()
        result = parse_data_info_block(block)
        assert result["bits_per_pixel"] == 16
    
    def test_dimensions(self):
        block = create_mock_data_info_block(nlines=5500, ncols=5500)
        result = parse_data_info_block(block)
        assert result["number_of_lines"] == 5500
        assert result["number_of_columns"] == 5500
    
    def test_compression_flag(self):
        block = create_mock_data_info_block()
        result = parse_data_info_block(block)
        assert result["compression_flag"] == 0


class TestProjectionBlock:
    """Tests for projection information block parser."""
    
    def test_sub_lon(self):
        block = create_mock_projection_block()
        result = parse_projection_block(block)
        assert abs(result["sub_lon"] - 140.7) < 0.001
    
    def test_distance(self):
        block = create_mock_projection_block()
        result = parse_projection_block(block)
        assert abs(result["distance"] - 42164.0) < 0.1


class TestCalibrationBlock:
    """Tests for calibration information block parser."""
    
    def test_visible_band_number(self):
        block = create_mock_calibration_block_visible()
        result = parse_calibration_block(block)
        assert result["band_number"] == 1
    
    def test_visible_slope(self):
        block = create_mock_calibration_block_visible()
        result = parse_calibration_block(block)
        assert abs(result["slope"] - 0.001) < 1e-6
    
    def test_visible_c_prime(self):
        block = create_mock_calibration_block_visible()
        result = parse_calibration_block(block)
        assert abs(result["c_prime"] - 100.0) < 0.1
    
    def test_ir_band_number(self):
        block = create_mock_calibration_block_ir()
        result = parse_calibration_block(block)
        assert result["band_number"] == 13
    
    def test_ir_central_wavelength(self):
        block = create_mock_calibration_block_ir()
        result = parse_calibration_block(block)
        assert abs(result["central_wavelength"] - 10.4) < 0.01


class TestFullHSDFile:
    """Integration tests for complete HSD file parsing."""
    
    def test_parse_visible_band(self):
        """Test parsing a complete mock HSD file for visible band."""
        mock_data = create_mock_hsd_file(nlines=100, ncols=100, band=1)
        image, headers = parse_hsd_file(mock_data)
        
        assert image.shape == (100, 100)
        assert headers.get_band_number() == 1
        assert headers.get_satellite_name() == "Himawari-9"
        assert headers.get_observation_area() == "FLDK"
    
    def test_parse_ir_band(self):
        """Test parsing a complete mock HSD file for IR band."""
        mock_data = create_mock_hsd_file(nlines=200, ncols=200, band=13)
        image, headers = parse_hsd_file(mock_data)
        
        assert image.shape == (200, 200)
        assert headers.get_band_number() == 13
    
    def test_pixel_values_valid(self):
        """Test that pixel values are in valid range."""
        mock_data = create_mock_hsd_file(nlines=50, ncols=50, band=1)
        image, headers = parse_hsd_file(mock_data)
        
        # All values should be non-zero (we set them that way)
        assert np.all(image > 0)
        # All values should be < 65535 (fill value)
        assert np.all(image < 65535)
    
    def test_dimensions_match_header(self):
        """Test that extracted image matches header dimensions."""
        nlines, ncols = 150, 250
        mock_data = create_mock_hsd_file(nlines=nlines, ncols=ncols, band=3)
        image, headers = parse_hsd_file(mock_data)
        
        dims = headers.get_dimensions()
        assert dims == (nlines, ncols)
        assert image.shape == (nlines, ncols)


class TestHSDHeaders:
    """Tests for the HSDHeaders dataclass."""
    
    def test_default_values(self):
        headers = HSDHeaders()
        assert headers.get_band_number() == 0
        assert headers.get_bits_per_pixel() == 16
        assert headers.get_satellite_name() == "Unknown"
    
    def test_band_number(self):
        headers = HSDHeaders()
        headers.calibration["band_number"] = 5
        assert headers.get_band_number() == 5
