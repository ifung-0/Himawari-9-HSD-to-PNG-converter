"""
API endpoint tests for the FastAPI application.

Tests all endpoints including health check, conversion, and info endpoints.
Uses mocking to avoid actual HTTP downloads.
"""

import io
import struct
from unittest.mock import patch, MagicMock, AsyncMock

import pytest
import numpy as np
from fastapi.testclient import TestClient
from httpx import Response as HttpxResponse

from src.main import app


# Create a minimal mock HSD file for testing
def create_minimal_hsd(nlines: int = 10, ncols: int = 10) -> bytes:
    """Create a minimal valid HSD file for testing."""
    file_data = bytearray()
    
    def add_block(block_num: int, block_content: bytes):
        """Add a block with proper 4-byte external header."""
        total_len = 4 + len(block_content)
        file_data.extend(struct.pack(">H", block_num))
        file_data.extend(struct.pack(">H", total_len))
        file_data.extend(block_content)
    
    # Block 1: Basic Info (282 bytes total = 4 header + 278 content)
    content = bytearray()
    content.append(1)
    content.extend(struct.pack(">H", 282))
    content.extend(struct.pack(">H", 11))  # total header blocks
    content.append(1)  # big endian
    name = b"Himawari-9"
    content.extend(name + b"\x00" * (16 - len(name)))
    center = b"MSC"
    content.extend(center + b"\x00" * (16 - len(center)))
    content.extend(b"FLDK")
    content.extend(b"\x00\x00")
    content.extend(struct.pack(">H", 400))
    content.extend(struct.pack(">d", 60600.0))
    content.extend(struct.pack(">d", 60600.006944))
    content.extend(struct.pack(">d", 60600.01))
    content.extend(struct.pack(">I", 1800))
    content.extend(struct.pack(">I", 200))
    content.extend(b"\x00" * 40)
    content.extend(b"\x00\x00\x00\x00")
    version = b"1.3"
    content.extend(version + b"\x00" * (32 - len(version)))
    filename = b"HS_H09_20260404_0400_B01_FLDK_R10_S1010.DAT"
    content.extend(filename + b"\x00" * (128 - len(filename)))
    content.extend(b"\x00" * 40)
    while len(content) < 278:
        content.append(0)
    add_block(1, bytes(content))
    
    # Block 2: Data Info (50 bytes total = 4 header + 46 content)
    content = bytearray()
    content.append(2)
    content.extend(struct.pack(">H", 50))
    content.extend(struct.pack(">H", 16))  # bits per pixel
    content.extend(struct.pack(">H", ncols))
    content.extend(struct.pack(">H", nlines))
    content.append(0)  # no compression
    content.extend(b"\x00" * 40)
    add_block(2, bytes(content))
    
    # Block 3: Projection (127 bytes total = 4 header + 123 content)
    content = bytearray()
    content.append(3)
    content.extend(struct.pack(">H", 127))
    content.extend(struct.pack(">d", 140.7))
    content.extend(struct.pack(">I", 40932549))
    content.extend(struct.pack(">I", 40932549))
    content.extend(struct.pack(">f", 5500.5))
    content.extend(struct.pack(">f", 5500.5))
    content.extend(struct.pack(">d", 42164.0))
    content.extend(struct.pack(">d", 6378.137))
    content.extend(struct.pack(">d", 6356.7523))
    content.extend(struct.pack(">d", 0.006694))
    content.extend(struct.pack(">d", 0.9933))
    content.extend(struct.pack(">d", 1.0067))
    content.extend(struct.pack(">d", 1737122264.0))
    content.extend(struct.pack(">H", 0))
    content.extend(struct.pack(">H", 0))
    content.extend(b"\x00" * 40)
    add_block(3, bytes(content))
    
    # Block 4: Navigation (139 bytes total = 4 header + 135 content)
    content = bytearray()
    content.append(4)
    content.extend(struct.pack(">H", 139))
    content.extend(b"\x00" * 135)
    add_block(4, bytes(content))
    
    # Block 5: Calibration - visible band (147 bytes total = 4 header + 143 content)
    content = bytearray()
    content.append(5)
    content.extend(struct.pack(">H", 147))
    content.extend(struct.pack(">H", 1))  # band 1
    content.extend(struct.pack(">d", 0.47))  # wavelength
    content.extend(struct.pack(">H", 11))  # valid bits
    content.extend(struct.pack(">H", 65535))  # error count
    content.extend(struct.pack(">H", 65534))  # outside count
    content.extend(struct.pack(">d", 0.001))  # slope
    content.extend(struct.pack(">d", 0.0))  # intercept
    content.extend(struct.pack(">d", 100.0))  # c_prime
    content.extend(struct.pack(">d", 60600.0))  # update time
    content.extend(struct.pack(">d", 0.001))  # updated slope
    content.extend(struct.pack(">d", 0.0))  # updated intercept
    content.extend(b"\x00" * 40)  # spare
    content.extend(b"\x00" * 40)  # spare
    add_block(5, bytes(content))
    
    # Blocks 6-11: simplified
    for block_num in [6, 7, 8, 9, 10, 11]:
        content_len = 255 if block_num == 11 else 96
        content = bytearray()
        content.append(block_num)
        content.extend(struct.pack(">H", content_len + 4))
        content.extend(b"\x00" * (content_len - 3))
        add_block(block_num, bytes(content))
    
    # Block 12: Data (4 header + pixel data)
    pixel_size = nlines * ncols * 2
    add_block(12, b"")  # empty content, pixel data follows header
    
    # Simple pixel data
    for i in range(nlines):
        for j in range(ncols):
            value = 1000 + i * 10 + j  # Simple gradient
            file_data.extend(struct.pack(">H", value))
    
    return bytes(file_data)


# Compress data with bz2 for download mocking
import bz2
MOCK_HSD_DATA = create_minimal_hsd(10, 10)
MOCK_BZ2_DATA = bz2.compress(MOCK_HSD_DATA)


@pytest.fixture
def client():
    """Create a test client."""
    return TestClient(app)


class TestHealthEndpoint:
    """Tests for the health check endpoint."""
    
    def test_health_status(self, client):
        response = client.get("/health")
        assert response.status_code == 200
        assert response.json()["status"] == "ok"
    
    def test_health_content_type(self, client):
        response = client.get("/health")
        assert response.headers["content-type"] == "application/json"


class TestIndexEndpoint:
    """Tests for the main UI page."""
    
    def test_index_status(self, client):
        response = client.get("/")
        assert response.status_code == 200
    
    def test_index_content_type(self, client):
        response = client.get("/")
        assert "text/html" in response.headers["content-type"]
    
    def test_index_contains_title(self, client):
        response = client.get("/")
        assert "Himawari-9" in response.text


class TestConvertEndpoint:
    """Tests for the conversion endpoint."""
    
    @pytest.mark.asyncio
    @patch("src.main.download_and_decompress")
    def test_convert_success(self, mock_download, client):
        """Test successful conversion with mocked download."""
        mock_download.return_value = MOCK_HSD_DATA
        
        response = client.get(
            "/convert",
            params={
                "url": "https://example.com/test.DAT.bz2",
                "enhancement": "linear"
            }
        )
        
        assert response.status_code == 200
        assert response.headers["content-type"] == "image/png"
        assert "attachment" in response.headers["content-disposition"]
    
    def test_convert_invalid_url(self, client):
        """Test conversion with invalid URL."""
        response = client.get(
            "/convert",
            params={"url": "not-a-url"}
        )
        assert response.status_code == 400
        assert "Invalid URL" in response.json()["detail"]
    
    def test_convert_missing_url(self, client):
        """Test conversion without URL parameter."""
        response = client.get("/convert")
        assert response.status_code == 422  # FastAPI validation error
    
    def test_convert_invalid_enhancement(self, client):
        """Test conversion with invalid enhancement type."""
        response = client.get(
            "/convert",
            params={
                "url": "https://example.com/test.DAT.bz2",
                "enhancement": "invalid"
            }
        )
        assert response.status_code == 400


class TestInfoEndpoint:
    """Tests for the info endpoint."""
    
    @pytest.mark.asyncio
    @patch("src.main.download_and_decompress")
    def test_info_success(self, mock_download, client):
        """Test successful info retrieval."""
        mock_download.return_value = MOCK_HSD_DATA
        
        response = client.get(
            "/api/info",
            params={"url": "https://example.com/test.DAT.bz2"}
        )
        
        assert response.status_code == 200
        data = response.json()
        assert data["satellite"] == "Himawari-9"
        assert data["band_number"] == 1
        assert data["observation_area"] == "FLDK"
    
    def test_info_invalid_url(self, client):
        """Test info with invalid URL."""
        response = client.get(
            "/api/info",
            params={"url": "ftp://invalid"}
        )
        assert response.status_code == 400


class TestErrorHandling:
    """Tests for error handling."""
    
    @patch("src.main.download_and_decompress")
    def test_convert_download_error(self, mock_download, client):
        """Test handling of download failures."""
        from fastapi import HTTPException
        mock_download.side_effect = HTTPException(status_code=404, detail="Not found")
        
        response = client.get(
            "/convert",
            params={"url": "https://example.com/missing.DAT.bz2"}
        )
        assert response.status_code == 404
