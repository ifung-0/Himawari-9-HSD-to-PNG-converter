"""
Pytest tests for Himawari-9 HSD Converter API

Tests all HTTP error scenarios:
- 400: Invalid URL, invalid format, invalid enhancement, invalid green correction
- 404: File not found
- 413: Payload too large
- 504: Gateway timeout / connection error
- 500: Processing error
"""

import pytest
import asyncio
from unittest.mock import patch, MagicMock, AsyncMock
from fastapi.testclient import TestClient
from fastapi import HTTPException
import httpx

from app.main import app, validate_url, download_file, MAX_FILE_SIZE

client = TestClient(app)


class TestValidateUrl:
    """Test URL validation"""
    
    def test_valid_url(self):
        """Should not raise for valid NOAA S3 URL"""
        validate_url("https://noaa-himawari9.s3.amazonaws.com/HSF-ext/2024/01/test.DAT.bz2")
    
    def test_empty_url(self):
        """400: Empty URL should raise 400"""
        with pytest.raises(HTTPException) as exc:
            validate_url("")
        assert exc.value.status_code == 400
        assert "Invalid URL" in exc.value.detail
    
    def test_invalid_protocol(self):
        """400: URL without http/https"""
        with pytest.raises(HTTPException) as exc:
            validate_url("ftp://noaa-himawari9.s3.amazonaws.com/test")
        assert exc.value.status_code == 400
    
    def test_wrong_host(self):
        """400: URL not from NOAA S3 bucket"""
        with pytest.raises(HTTPException) as exc:
            validate_url("https://evil-bucket.s3.amazonaws.com/test")
        assert exc.value.status_code == 400
        assert "noaa-himawari9" in exc.value.detail
    
    def test_none_url(self):
        """400: None URL"""
        with pytest.raises(HTTPException) as exc:
            validate_url(None)
        assert exc.value.status_code == 400


class TestConvertEndpoint:
    """Test GET /convert endpoint"""
    
    def test_convert_invalid_format(self):
        """400: Invalid format parameter"""
        response = client.get(
            "/convert",
            params={
                "url": "https://noaa-himawari9.s3.amazonaws.com/test.DAT.bz2",
                "format": "jpg"
            }
        )
        assert response.status_code == 400
        assert "Invalid format" in response.json()["detail"]
    
    def test_convert_invalid_enhancement(self):
        """400: Invalid enhancement parameter"""
        response = client.get(
            "/convert",
            params={
                "url": "https://noaa-himawari9.s3.amazonaws.com/test.DAT.bz2",
                "enhancement": "fake"
            }
        )
        assert response.status_code == 400
        assert "Invalid enhancement" in response.json()["detail"]
    
    def test_convert_invalid_url_host(self):
        """400: URL not from allowed host"""
        response = client.get(
            "/convert",
            params={"url": "https://other-bucket.s3.amazonaws.com/test.DAT.bz2"}
        )
        assert response.status_code == 400
        assert "noaa-himawari9" in response.json()["detail"]
    
    @patch("app.main.download_file")
    def test_convert_404_not_found(self, mock_download):
        """404: File not found at URL"""
        mock_download.side_effect = HTTPException(status_code=404, detail="File not found at URL")
        
        response = client.get(
            "/convert",
            params={"url": "https://noaa-himawari9.s3.amazonaws.com/nonexistent.DAT.bz2"}
        )
        assert response.status_code == 404
    
    @patch("app.main.download_file")
    def test_convert_413_too_large(self, mock_download):
        """413: File size exceeds limit"""
        mock_download.side_effect = HTTPException(
            status_code=413,
            detail=f"File size exceeds maximum allowed"
        )
        
        response = client.get(
            "/convert",
            params={"url": "https://noaa-himawari9.s3.amazonaws.com/huge.DAT.bz2"}
        )
        assert response.status_code == 413
    
    @patch("app.main.download_file")
    def test_convert_504_timeout(self, mock_download):
        """504: Download timeout"""
        mock_download.side_effect = HTTPException(
            status_code=504,
            detail="Download timed out"
        )
        
        response = client.get(
            "/convert",
            params={"url": "https://noaa-himawari9.s3.amazonaws.com/test.DAT.bz2"}
        )
        assert response.status_code == 504
    
    @patch("app.main.download_file")
    @patch("app.main.decompress_bz2")
    @patch("app.main.parse_hsd_file")
    def test_convert_500_parse_error(self, mock_parse, mock_decompress, mock_download):
        """500: Parser error during processing"""
        mock_download.return_value = b"fake compressed data"
        mock_decompress.return_value = b"fake hsd data"
        mock_parse.side_effect = Exception("Corrupt HSD block 3")
        
        response = client.get(
            "/convert",
            params={"url": "https://noaa-himawari9.s3.amazonaws.com/test.DAT.bz2"}
        )
        assert response.status_code == 500
        assert "Processing error" in response.json()["detail"]


class TestTruecolorEndpoint:
    """Test GET /truecolor endpoint"""
    
    def test_truecolor_invalid_format(self):
        """400: Invalid format parameter"""
        response = client.get(
            "/truecolor",
            params={
                "b01_url": "https://noaa-himawari9.s3.amazonaws.com/B01.DAT.bz2",
                "b02_url": "https://noaa-himawari9.s3.amazonaws.com/B02.DAT.bz2",
                "b03_url": "https://noaa-himawari9.s3.amazonaws.com/B03.DAT.bz2",
                "format": "gif"
            }
        )
        assert response.status_code == 400
        assert "Invalid format" in response.json()["detail"]
    
    def test_truecolor_invalid_enhancement(self):
        """400: Invalid enhancement parameter"""
        response = client.get(
            "/truecolor",
            params={
                "b01_url": "https://noaa-himawari9.s3.amazonaws.com/B01.DAT.bz2",
                "b02_url": "https://noaa-himawari9.s3.amazonaws.com/B02.DAT.bz2",
                "b03_url": "https://noaa-himawari9.s3.amazonaws.com/B03.DAT.bz2",
                "enhancement": "fake"
            }
        )
        assert response.status_code == 400
        assert "Invalid enhancement" in response.json()["detail"]
    
    def test_truecolor_invalid_green_correction_negative(self):
        """400: Green correction below 0"""
        response = client.get(
            "/truecolor",
            params={
                "b01_url": "https://noaa-himawari9.s3.amazonaws.com/B01.DAT.bz2",
                "b02_url": "https://noaa-himawari9.s3.amazonaws.com/B02.DAT.bz2",
                "b03_url": "https://noaa-himawari9.s3.amazonaws.com/B03.DAT.bz2",
                "green_correction": -0.5
            }
        )
        assert response.status_code == 400
        assert "Green correction" in response.json()["detail"]
    
    def test_truecolor_invalid_green_correction_over_one(self):
        """400: Green correction above 1"""
        response = client.get(
            "/truecolor",
            params={
                "b01_url": "https://noaa-himawari9.s3.amazonaws.com/B01.DAT.bz2",
                "b02_url": "https://noaa-himawari9.s3.amazonaws.com/B02.DAT.bz2",
                "b03_url": "https://noaa-himawari9.s3.amazonaws.com/B03.DAT.bz2",
                "green_correction": 1.5
            }
        )
        assert response.status_code == 400
        assert "Green correction" in response.json()["detail"]
    
    def test_truecolor_invalid_b01_url(self):
        """400: B01 URL from wrong host"""
        response = client.get(
            "/truecolor",
            params={
                "b01_url": "https://wrong-host.s3.amazonaws.com/B01.DAT.bz2",
                "b02_url": "https://noaa-himawari9.s3.amazonaws.com/B02.DAT.bz2",
                "b03_url": "https://noaa-himawari9.s3.amazonaws.com/B03.DAT.bz2"
            }
        )
        assert response.status_code == 400
        assert "noaa-himawari9" in response.json()["detail"]
    
    @patch("app.main.download_file")
    def test_truecolor_404_band_missing(self, mock_download):
        """404: One of the bands not found"""
        mock_download.side_effect = HTTPException(status_code=404, detail="File not found at URL")
        
        response = client.get(
            "/truecolor",
            params={
                "b01_url": "https://noaa-himawari9.s3.amazonaws.com/B01.DAT.bz2",
                "b02_url": "https://noaa-himawari9.s3.amazonaws.com/B02.DAT.bz2",
                "b03_url": "https://noaa-himawari9.s3.amazonaws.com/B03.DAT.bz2"
            }
        )
        assert response.status_code == 404
    
    @patch("app.main.download_file")
    def test_truecolor_413_too_large(self, mock_download):
        """413: Combined download too large"""
        mock_download.side_effect = HTTPException(
            status_code=413,
            detail="Payload Too Large"
        )
        
        response = client.get(
            "/truecolor",
            params={
                "b01_url": "https://noaa-himawari9.s3.amazonaws.com/B01.DAT.bz2",
                "b02_url": "https://noaa-himawari9.s3.amazonaws.com/B02.DAT.bz2",
                "b03_url": "https://noaa-himawari9.s3.amazonaws.com/B03.DAT.bz2"
            }
        )
        assert response.status_code == 413
    
    @patch("app.main.download_file")
    def test_truecolor_504_timeout(self, mock_download):
        """504: Timeout downloading bands"""
        mock_download.side_effect = HTTPException(
            status_code=504,
            detail="Download timed out"
        )
        
        response = client.get(
            "/truecolor",
            params={
                "b01_url": "https://noaa-himawari9.s3.amazonaws.com/B01.DAT.bz2",
                "b02_url": "https://noaa-himawari9.s3.amazonaws.com/B02.DAT.bz2",
                "b03_url": "https://noaa-himawari9.s3.amazonaws.com/B03.DAT.bz2"
            }
        )
        assert response.status_code == 504


class TestHealthEndpoint:
    """Test GET /health endpoint"""
    
    def test_health(self):
        """Should return healthy status"""
        response = client.get("/health")
        assert response.status_code == 200
        assert response.json()["status"] == "healthy"


class TestDownloadFile:
    """Test download_file function"""
    
    @pytest.mark.asyncio
    @patch("httpx.AsyncClient")
    async def test_download_timeout(self, mock_client_class):
        """504: httpx timeout during download"""
        mock_client = AsyncMock()
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=None)
        mock_client.head = AsyncMock(side_effect=httpx.TimeoutException("Connection timed out"))
        mock_client_class.return_value = mock_client
        
        with pytest.raises(HTTPException) as exc:
            await download_file("https://noaa-himawari9.s3.amazonaws.com/test.bz2")
        assert exc.value.status_code == 504
        assert "timed out" in exc.value.detail.lower()
    
    @pytest.mark.asyncio
    @patch("httpx.AsyncClient")
    async def test_download_connect_error(self, mock_client_class):
        """504: Connection error"""
        mock_client = AsyncMock()
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=None)
        mock_client.head = AsyncMock(side_effect=httpx.ConnectError("Connection refused"))
        mock_client_class.return_value = mock_client
        
        with pytest.raises(HTTPException) as exc:
            await download_file("https://noaa-himawari9.s3.amazonaws.com/test.bz2")
        assert exc.value.status_code == 504
        assert "Failed to connect" in exc.value.detail


class TestDecompressBz2:
    """Test bz2 decompression"""
    
    def test_decompress_valid(self):
        """Should decompress valid bz2 data"""
        import bz2
        original = b"test data for compression"
        compressed = bz2.compress(original)
        
        from app.main import decompress_bz2
        result = decompress_bz2(compressed)
        assert result == original
    
    def test_decompress_raw_data(self):
        """Should return raw data if decompression fails"""
        from app.main import decompress_bz2
        raw = b"already decompressed raw data"
        result = decompress_bz2(raw)
        assert result == raw
