"""
Test HSD Parser with synthetic data that mimics real Himawari-9 HSD format structure.

These tests verify the binary parser correctly handles all block types and edge cases.
"""

import struct
import numpy as np
import pytest

from app.hsd_parser import (
    parse_basic_info, parse_data_info, parse_projection_info,
    parse_navigation_info, parse_calibration_info, parse_data_block,
    parse_hsd_file, calibrate_data
)
from app.hsd_parser import BasicInfo, DataInfo, ProjectionInfo, CalibrationInfo, HSDFile


def build_basic_info_block(
    satellite="HIMAWARI-9",
    area="FLDK",
    timeline=10,
    header_len=0,  # computed later
    data_len=0     # computed later
):
    """Build Block 1: Basic Information with correct size"""
    body = b''
    body += satellite.encode('ascii').ljust(16, b' ')
    body += b'MSC '  # processing center
    body += area.encode('ascii').ljust(4, b' ')  # observation area
    body += b'  '  # other info (2 bytes)
    body += struct.pack('>H', timeline)  # observation timeline (2 bytes)
    body += b'2024-01-15 06:00:00.000                     '  # start time (32 bytes)
    body += b'2024-01-15 06:00:10.000                     '  # end time (32 bytes)
    body += b'2024-01-15 06:05:00.000                     '  # file creation time (32 bytes)
    body += struct.pack('>I', header_len)  # total header length (4 bytes)
    body += struct.pack('>I', data_len)    # total data length (4 bytes)
    body += struct.pack('>B', 0)  # quality flag (1 byte)
    body += b' ' * 40  # spare (40 bytes)
    
    block_len = 4 + len(body)  # 2 (block num) + 2 (block len) + body
    return struct.pack('>HH', 1, block_len) + body, block_len


def build_data_info_block(ncols=5500, nlines=5500, bpp=16):
    """Build Block 2: Data Information"""
    body = b''
    body += struct.pack('>H', bpp)        # bits per pixel (2 bytes)
    body += struct.pack('>H', ncols)      # columns (2 bytes)
    body += struct.pack('>H', nlines)     # lines (2 bytes)
    body += struct.pack('>B', 0)          # compression flag (1 byte)
    body += b' ' * 40                      # spare (40 bytes)
    
    block_len = 4 + len(body)
    return struct.pack('>HH', 2, block_len) + body, block_len


def build_projection_info_block():
    """Build Block 3: Projection Information"""
    body = b''
    body += struct.pack('>d', 140.7)           # sub_lon (8 bytes)
    body += struct.pack('>d', 0.0)             # sub_lat (8 bytes)
    body += struct.pack('>d', 42164000.0)      # distance (8 bytes)
    body += struct.pack('>d', 6378137.0)       # equatorial radius (8 bytes)
    body += struct.pack('>d', 6356752.314245)  # polar radius (8 bytes)
    body += struct.pack('>d', 20466275.0)      # cfac (8 bytes)
    body += struct.pack('>d', 20466275.0)      # lfac (8 bytes)
    body += struct.pack('>d', 2750.5)          # coff (8 bytes)
    body += struct.pack('>d', 2750.5)          # loff (8 bytes)
    body += struct.pack('>B', 0)               # image flip E/W (1 byte)
    body += struct.pack('>B', 0)               # image flip N/S (1 byte)
    body += b' ' * 52                           # spare (52 bytes)
    
    block_len = 4 + len(body)
    return struct.pack('>HH', 3, block_len) + body, block_len


def build_navigation_info_block():
    """Build Block 4: Navigation Information"""
    body = b''
    body += struct.pack('>d', 0.0)        # sat position x (8 bytes)
    body += struct.pack('>d', 0.0)        # sat position y (8 bytes)
    body += struct.pack('>d', 42164000.0) # sat position z (8 bytes)
    body += struct.pack('>d', 0.0)        # sat velocity x (8 bytes)
    body += struct.pack('>d', 0.0)        # sat velocity y (8 bytes)
    body += struct.pack('>d', 0.0)        # sat velocity z (8 bytes)
    body += b' ' * 40                      # spare (40 bytes)
    
    block_len = 4 + len(body)
    return struct.pack('>HH', 4, block_len) + body, block_len


def build_calibration_info_block(band=3, slope=0.01, intercept=0.0):
    """Build Block 5: Calibration Information"""
    body = b''
    body += struct.pack('>H', band)         # band number (2 bytes)
    body += struct.pack('>d', 0.64)         # central wavelength (8 bytes)
    body += struct.pack('>H', 16)           # valid bits per pixel (2 bytes)
    body += struct.pack('>h', 0)            # count value error (2 bytes)
    body += struct.pack('>h', -1)           # count value outside scan (2 bytes)
    body += struct.pack('>h', 1023)         # count value inside scan (2 bytes)
    body += struct.pack('>d', slope)        # slope (8 bytes)
    body += struct.pack('>d', intercept)    # intercept (8 bytes)
    body += b' ' * 80                        # spare (80 bytes)
    
    block_len = 4 + len(body)
    return struct.pack('>HH', 5, block_len) + body, block_len


def build_data_block(ncols=100, nlines=100, bpp=16):
    """Build Block 6: Data Block with test pixel values"""
    pixels = np.zeros((nlines, ncols), dtype='>u2')
    for i in range(nlines):
        for j in range(ncols):
            pixels[i, j] = (i + j) % 1024  # gradient pattern
    
    pixel_bytes = pixels.tobytes()
    block_len = 4 + len(pixel_bytes)
    return struct.pack('>HH', 6, block_len) + pixel_bytes, block_len, pixels


def build_synthetic_hsd(ncols=100, nlines=100, band=3, slope=0.01):
    """Build a complete synthetic HSD file with correct block lengths"""
    # First pass: compute data block to know sizes
    data_block, data_block_len, pixel_array = build_data_block(ncols, nlines)
    pixel_data_len = len(data_block)
    
    # Compute total lengths
    total_data_len = pixel_data_len
    
    # Build all blocks
    basic_block, basic_len = build_basic_info_block(
        header_len=0,  # will update
        data_len=total_data_len
    )
    data_info_block, data_info_len = build_data_info_block(ncols, nlines)
    proj_block, proj_len = build_projection_info_block()
    nav_block, nav_len = build_navigation_info_block()
    cal_block, cal_len = build_calibration_info_block(band, slope)
    
    # Compute actual header length
    header_len = basic_len + data_info_len + proj_len + nav_len + cal_len
    
    # Rebuild basic info with correct header length
    basic_block, basic_len = build_basic_info_block(
        header_len=header_len,
        data_len=total_data_len
    )
    
    # Combine all blocks
    file_data = basic_block + data_info_block + proj_block + nav_block + cal_block + data_block
    
    return file_data, pixel_array


class TestBasicInfo:
    """Test Block 1 parsing"""
    
    def test_parse_basic_info(self):
        block, _ = build_basic_info_block()
        info = parse_basic_info(block)
        
        assert isinstance(info, BasicInfo)
        assert info.header_block_number == 1
        assert info.satellite_name == "HIMAWARI-9"
        assert info.observation_area == "FLDK"
        assert info.observation_timeline == 10


class TestDataInfo:
    """Test Block 2 parsing"""
    
    def test_parse_data_info(self):
        block, _ = build_data_info_block(ncols=5500, nlines=5500, bpp=16)
        info = parse_data_info(block)
        
        assert isinstance(info, DataInfo)
        assert info.header_block_number == 2
        assert info.bits_per_pixel == 16
        assert info.number_of_columns == 5500
        assert info.number_of_lines == 5500


class TestProjectionInfo:
    """Test Block 3 parsing"""
    
    def test_parse_projection_info(self):
        block, _ = build_projection_info_block()
        info = parse_projection_info(block)
        
        assert isinstance(info, ProjectionInfo)
        assert info.header_block_number == 3
        assert info.sub_lon == 140.7
        assert info.distance_earth_center_to_satellite == 42164000.0
        assert info.cfac == 20466275.0
        assert info.coff == 2750.5
    
    def test_georeferencing_computed(self):
        block, _ = build_projection_info_block()
        info = parse_projection_info(block)
        
        assert len(info.geotransform) == 6
        assert info.geotransform[1] > 0  # x pixel size positive
        assert info.geotransform[5] < 0  # y pixel size negative (north-up)
        assert "GEOGCS" in info.crs_wkt


class TestNavigationInfo:
    """Test Block 4 parsing"""
    
    def test_parse_navigation_info(self):
        block, _ = build_navigation_info_block()
        info = parse_navigation_info(block)
        
        assert info.header_block_number == 4
        assert info.sat_position_z == 42164000.0


class TestCalibrationInfo:
    """Test Block 5 parsing"""
    
    def test_parse_calibration_info(self):
        block, _ = build_calibration_info_block(band=3, slope=0.01, intercept=0.0)
        info = parse_calibration_info(block)
        
        assert isinstance(info, CalibrationInfo)
        assert info.header_block_number == 5
        assert info.band_number == 3
        assert info.slope == 0.01
        assert info.intercept == 0.0
        assert info.central_wave_length == 0.64


class TestDataBlock:
    """Test Block 6 parsing"""
    
    def test_parse_data_block(self):
        ncols, nlines = 50, 50
        block, _, expected_pixels = build_data_block(ncols=ncols, nlines=nlines)
        # Skip block header (4 bytes)
        parsed = parse_data_block(block[4:], ncols, nlines, 16)
        
        assert parsed.shape == (nlines, ncols)
        assert parsed.dtype == np.uint16
        assert parsed.max() > 0
        # Check first few values match
        assert parsed[0, 0] == 0
        assert parsed[1, 1] == 2  # (1+1) % 1024


class TestParseHSDFile:
    """Test complete HSD file parsing"""
    
    def test_parse_complete_file(self):
        file_data, expected_pixels = build_synthetic_hsd(ncols=50, nlines=50)
        hsd = parse_hsd_file(file_data)
        
        assert isinstance(hsd, HSDFile)
        assert hsd.basic_info.satellite_name == "HIMAWARI-9"
        assert hsd.data_info.number_of_columns == 50
        assert hsd.data_info.number_of_lines == 50
        assert hsd.pixel_data is not None
        assert hsd.pixel_data.shape == (50, 50)
    
    def test_parse_ir_band(self):
        file_data, _ = build_synthetic_hsd(ncols=50, nlines=50, band=13)
        hsd = parse_hsd_file(file_data)
        assert hsd.calibration_info.band_number == 13


class TestCalibration:
    """Test data calibration"""
    
    def test_calibrate_visible(self):
        file_data, _ = build_synthetic_hsd(ncols=50, nlines=50, band=3, slope=0.01)
        hsd = parse_hsd_file(file_data)
        calibrated = calibrate_data(hsd)
        
        assert calibrated.dtype == np.float32
        assert calibrated.shape == (50, 50)
        # With slope=0.01 and intercept=0, max should be ~10.23 (1023 * 0.01)
        assert calibrated.max() <= 10.24


class TestEdgeCases:
    """Test edge cases and error handling"""
    
    def test_small_image(self):
        """Parse very small image"""
        file_data, _ = build_synthetic_hsd(ncols=2, nlines=2)
        hsd = parse_hsd_file(file_data)
        assert hsd.pixel_data.shape == (2, 2)
    
    def test_11bit_data(self):
        """Test 11-bit visible band"""
        # Build custom with 11bpp
        ncols, nlines = 10, 10
        data_block, data_block_len, pixels = build_data_block(ncols=ncols, nlines=nlines)
        
        basic_block, _ = build_basic_info_block(data_len=len(data_block))
        data_info_block, _ = build_data_info_block(ncols=ncols, nlines=nlines, bpp=11)
        proj_block, _ = build_projection_info_block()
        nav_block, _ = build_navigation_info_block()
        cal_block, _ = build_calibration_info_block(band=1)
        
        file_data = basic_block + data_info_block + proj_block + nav_block + cal_block + data_block
        
        hsd = parse_hsd_file(file_data)
        assert hsd.data_info.bits_per_pixel == 11
        assert hsd.pixel_data.shape == (10, 10)
    
    def test_error_pixels_masked(self):
        """Test that error pixels (65535) are masked to 0"""
        ncols, nlines = 10, 10
        pixels = np.full((nlines, ncols), 65535, dtype='>u2')  # all error values
        pixels[0, 0] = 100  # one valid pixel
        
        pixel_bytes = pixels.tobytes()
        block_len = 4 + len(pixel_bytes)
        block = struct.pack('>HH', 6, block_len) + pixel_bytes
        
        parsed = parse_data_block(block[4:], ncols, nlines, 16)
        assert parsed[0, 0] == 100  # Valid pixel preserved
        assert parsed[1, 1] == 0    # Error pixels masked to 0
