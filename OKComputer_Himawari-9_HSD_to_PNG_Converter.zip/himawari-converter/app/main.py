"""
Himawari-9 HSD to PNG Converter - FastAPI Application

API Endpoints:
- GET /convert: Convert single HSD file to PNG or GeoTIFF
- GET /truecolor: Create RGB true-color composite from B01, B02, B03
"""

import io
import re
import bz2
import logging
import asyncio
from typing import Optional
from pathlib import Path

import httpx
import numpy as np
from fastapi import FastAPI, HTTPException, Query, Request
from fastapi.responses import Response, HTMLResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware

from app.hsd_parser import parse_hsd_file, calibrate_data
from app.processing import render_to_png, create_geotiff, create_truecolor_composite

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(
    title="Himawari-9 HSD Converter",
    description="Convert Himawari-9 satellite HSD data to PNG or GeoTIFF",
    version="1.0.0"
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Configuration
MAX_FILE_SIZE = 500 * 1024 * 1024  # 500MB
REQUEST_TIMEOUT = 120  # seconds
ALLOWED_HOST = "noaa-himawari9.s3.amazonaws.com"


def validate_url(url: str) -> None:
    """Validate that URL points to allowed NOAA S3 bucket."""
    if not url or not url.startswith(("https://", "http://")):
        raise HTTPException(status_code=400, detail="Invalid URL format")
    
    if ALLOWED_HOST not in url:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid URL. Only {ALLOWED_HOST} is allowed"
        )


async def download_file(
    url: str,
    max_size: int = MAX_FILE_SIZE,
    timeout: int = REQUEST_TIMEOUT
) -> bytes:
    """Download file from URL with size and timeout checks.
    
    Args:
        url: URL to download from
        max_size: Maximum allowed file size in bytes
        timeout: Request timeout in seconds
    
    Returns:
        Downloaded file bytes
    
    Raises:
        HTTPException: For various error conditions
    """
    try:
        async with httpx.AsyncClient(timeout=timeout, follow_redirects=True) as client:
            logger.info(f"Downloading from: {url}")
            
            # First check file size with HEAD request
            head_response = await client.head(url)
            
            if head_response.status_code == 404:
                raise HTTPException(status_code=404, detail="File not found at URL")
            
            if head_response.status_code == 403:
                raise HTTPException(status_code=404, detail="File not accessible (may be expired)")
            
            content_length = head_response.headers.get('content-length')
            if content_length:
                size = int(content_length)
                if size > max_size:
                    raise HTTPException(
                        status_code=413,
                        detail=f"File size ({size / 1024 / 1024:.1f}MB) exceeds maximum allowed ({max_size / 1024 / 1024:.0f}MB)"
                    )
            
            # Download with streaming
            response = await client.get(url)
            
            if response.status_code == 404:
                raise HTTPException(status_code=404, detail="File not found at URL")
            
            response.raise_for_status()
            
            data = response.content
            
            if len(data) > max_size:
                raise HTTPException(
                    status_code=413,
                    detail=f"Downloaded file size ({len(data) / 1024 / 1024:.1f}MB) exceeds maximum allowed"
                )
            
            logger.info(f"Downloaded {len(data)} bytes")
            return data
            
    except httpx.TimeoutException:
        raise HTTPException(
            status_code=504,
            detail="Download timed out. Try a smaller file or check your connection."
        )
    except httpx.ConnectError:
        raise HTTPException(
            status_code=504,
            detail="Failed to connect to download server. Check your network connection."
        )
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 404:
            raise HTTPException(status_code=404, detail="File not found at URL")
        raise HTTPException(
            status_code=500,
            detail=f"HTTP error during download: {e.response.status_code}"
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Download error: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Download failed: {str(e)}")


def decompress_bz2(data: bytes) -> bytes:
    """Decompress bz2 data.
    
    Args:
        data: bz2 compressed bytes
    
    Returns:
        Decompressed bytes
    """
    try:
        return bz2.decompress(data)
    except Exception as e:
        # May already be decompressed
        logger.warning(f"BZ2 decompression failed, assuming raw data: {e}")
        return data


@app.get("/")
async def root():
    """Serve the main HTML page."""
    html_content = Path(__file__).parent / "static" / "index.html"
    if html_content.exists():
        return HTMLResponse(content=html_content.read_text())
    return HTMLResponse(content=get_default_html())


@app.get("/convert")
async def convert(
    url: str = Query(..., description="S3 URL of .dat.bz2 HSD file"),
    format: str = Query("png", description="Output format: png or tiff"),
    enhancement: str = Query("linear", description="Enhancement: linear, albedo, histogram")
):
    """Convert a single HSD file to PNG or GeoTIFF.
    
    Query Parameters:
    - url: S3 URL to the .dat.bz2 file
    - format: Output format ('png' or 'tiff')
    - enhancement: Image enhancement method ('linear', 'albedo', 'histogram')
    
    Returns:
        Image file (PNG or TIFF)
    """
    # Validate inputs
    if format not in ("png", "tiff"):
        raise HTTPException(status_code=400, detail="Invalid format. Use 'png' or 'tiff'")
    
    if enhancement not in ("linear", "albedo", "histogram"):
        raise HTTPException(
            status_code=400,
            detail="Invalid enhancement. Use 'linear', 'albedo', or 'histogram'"
        )
    
    validate_url(url)
    
    try:
        # Download file
        raw_data = await download_file(url)
        
        # Decompress
        hsd_data = decompress_bz2(raw_data)
        
        # Parse HSD
        hsd_file = parse_hsd_file(hsd_data)
        
        if format == "tiff":
            # Generate GeoTIFF
            tiff_bytes = create_geotiff(hsd_file)
            
            # Create filename
            band = hsd_file.calibration_info.band_number
            area = hsd_file.basic_info.observation_area.strip()
            start_time = hsd_file.basic_info.observation_start_time.strip()
            safe_time = re.sub(r'[^\w]', '_', start_time)
            filename = f"Himawari9_B{band:02d}_{area}_{safe_time}.tif"
            
            return Response(
                content=tiff_bytes,
                media_type="image/tiff",
                headers={"Content-Disposition": f'attachment; filename="{filename}"'}
            )
        else:
            # Generate PNG
            png_bytes = render_to_png(hsd_file, enhancement=enhancement)
            
            # Create filename
            band = hsd_file.calibration_info.band_number
            area = hsd_file.basic_info.observation_area.strip()
            start_time = hsd_file.basic_info.observation_start_time.strip()
            safe_time = re.sub(r'[^\w]', '_', start_time)
            filename = f"Himawari9_B{band:02d}_{area}_{safe_time}_{enhancement}.png"
            
            return Response(
                content=png_bytes,
                media_type="image/png",
                headers={"Content-Disposition": f'attachment; filename="{filename}"'}
            )
            
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Conversion error: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Processing error: {str(e)}")


@app.get("/truecolor")
async def truecolor(
    b01_url: str = Query(..., description="S3 URL for B01 (Blue) .dat.bz2 file"),
    b02_url: str = Query(..., description="S3 URL for B02 (Green) .dat.bz2 file"),
    b03_url: str = Query(..., description="S3 URL for B03 (Red) .dat.bz2 file"),
    format: str = Query("png", description="Output format: png or tiff"),
    green_correction: float = Query(0.45, description="Green correction factor (0-1)"),
    enhancement: str = Query("linear", description="Enhancement: linear, albedo, histogram")
):
    """Create true-color RGB composite from B01, B02, B03 bands.
    
    Uses JMA standard green correction:
    Green = B02 * (1 - alpha) + B03 * alpha
    
    Query Parameters:
    - b01_url: S3 URL for B01 (Blue, 470nm)
    - b02_url: S3 URL for B02 (Green, 510nm)
    - b03_url: S3 URL for B03 (Red, 640nm)
    - format: Output format ('png' or 'tiff')
    - green_correction: Green correction factor (default 0.45)
    - enhancement: Image enhancement method
    
    Returns:
        RGB composite image (PNG or TIFF)
    """
    # Validate inputs
    if format not in ("png", "tiff"):
        raise HTTPException(status_code=400, detail="Invalid format. Use 'png' or 'tiff'")
    
    if enhancement not in ("linear", "albedo", "histogram"):
        raise HTTPException(
            status_code=400,
            detail="Invalid enhancement. Use 'linear', 'albedo', or 'histogram'"
        )
    
    if not 0 <= green_correction <= 1:
        raise HTTPException(
            status_code=400,
            detail="Green correction must be between 0 and 1"
        )
    
    validate_url(b01_url)
    validate_url(b02_url)
    validate_url(b03_url)
    
    try:
        # Download all three bands concurrently
        b01_data, b02_data, b03_data = await asyncio.gather(
            download_file(b01_url),
            download_file(b02_url),
            download_file(b03_url)
        )
        
        # Decompress all
        hsd_b01 = parse_hsd_file(decompress_bz2(b01_data))
        hsd_b02 = parse_hsd_file(decompress_bz2(b02_data))
        hsd_b03 = parse_hsd_file(decompress_bz2(b03_data))
        
        if format == "tiff":
            # For TIFF, create 3-band GeoTIFF
            # Calibrate each band
            b01_cal = calibrate_data(hsd_b01)
            b02_cal = calibrate_data(hsd_b02)
            b03_cal = calibrate_data(hsd_b03)
            
            # Apply green correction for green channel
            green_corrected = b02_cal * (1 - green_correction) + b03_cal * green_correction
            
            # Stack: R=B03, G=corrected, B=B01
            rgb_data = np.stack([b03_cal, green_corrected, b01_cal], axis=0)
            
            # Use B03 as reference for georeferencing
            tiff_bytes = create_geotiff(hsd_b03, calibrated_data=rgb_data)
            
            area = hsd_b03.basic_info.observation_area.strip()
            start_time = hsd_b03.basic_info.observation_start_time.strip()
            safe_time = re.sub(r'[^\w]', '_', start_time)
            filename = f"Himawari9_TrueColor_{area}_{safe_time}.tif"
            
            return Response(
                content=tiff_bytes,
                media_type="image/tiff",
                headers={"Content-Disposition": f'attachment; filename="{filename}"'}
            )
        else:
            # Generate true-color PNG
            png_bytes = create_truecolor_composite(
                hsd_b01, hsd_b02, hsd_b03,
                green_correction=green_correction,
                enhancement=enhancement
            )
            
            area = hsd_b03.basic_info.observation_area.strip()
            start_time = hsd_b03.basic_info.observation_start_time.strip()
            safe_time = re.sub(r'[^\w]', '_', start_time)
            filename = f"Himawari9_TrueColor_{area}_{safe_time}_{enhancement}.png"
            
            return Response(
                content=png_bytes,
                media_type="image/png",
                headers={"Content-Disposition": f'attachment; filename="{filename}"'}
            )
            
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Truecolor conversion error: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Processing error: {str(e)}")


@app.get("/health")
async def health():
    """Health check endpoint."""
    return {"status": "healthy", "service": "himawari-converter"}


def get_default_html() -> str:
    """Return default HTML if static file not found."""
    return """<!DOCTYPE html>
<html><head><title>Himawari-9 Converter</title></head>
<body><h1>Himawari-9 HSD Converter</h1><p>Static files not loaded.</p></body></html>"""


# Mount static files
try:
    static_path = Path(__file__).parent / "static"
    if static_path.exists():
        app.mount("/static", StaticFiles(directory=str(static_path)), name="static")
except Exception:
    pass
