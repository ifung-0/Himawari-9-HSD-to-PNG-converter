"""
Himawari Standard Data (HSD) Parser
Implements the JMA HSD format specification for Himawari-9 satellite data.

HSD File Structure:
- Each block starts with: Block Number (uint16 BE) + Block Length (uint16 BE)
- Block 1: Basic Information
- Block 2: Data Information  
- Block 3: Projection Information
- Block 4: Navigation Information
- Block 5: Calibration Information
- Block 6: Data Block (pixel data)
"""

import struct
import io
import logging
from dataclasses import dataclass, field
from typing import Optional, Tuple, BinaryIO
import numpy as np

logger = logging.getLogger(__name__)


@dataclass
class BasicInfo:
    """Block 1: Basic Information"""
    header_block_number: int
    block_length: int
    satellite_name: str = ""
    processing_center: str = ""
    observation_area: str = ""
    other_info: str = ""
    observation_timeline: int = 0
    observation_start_time: str = ""
    observation_end_time: str = ""
    file_creation_time: str = ""
    total_header_length: int = 0
    total_data_length: int = 0
    quality_flag: int = 0
    spare: str = ""


@dataclass
class DataInfo:
    """Block 2: Data Information"""
    header_block_number: int
    block_length: int
    bits_per_pixel: int = 0
    number_of_columns: int = 0
    number_of_lines: int = 0
    compression_flag: int = 0
    spare: str = ""


@dataclass
class ProjectionInfo:
    """Block 3: Projection Information"""
    header_block_number: int
    block_length: int
    sub_lon: float = 0.0  # Sub-satellite longitude (degrees)
    sub_lat: float = 0.0  # Sub-satellite latitude (degrees)
    distance_earth_center_to_satellite: float = 0.0  # (m)
    equatorial_radius: float = 0.0  # (m)
    polar_radius: float = 0.0  # (m)
    cfac: float = 0.0  # Column scaling factor
    lfac: float = 0.0  # Line scaling factor
    coff: float = 0.0  # Column offset
    loff: float = 0.0  # Line offset
    image_flip_e_w: int = 0
    image_flip_n_s: int = 0
    spare: str = ""
    # Georeferencing computed fields
    geotransform: Tuple[float, ...] = field(default_factory=tuple)
    crs_wkt: str = ""


@dataclass
class NavigationInfo:
    """Block 4: Navigation Information"""
    header_block_number: int
    block_length: int
    sat_position_x: float = 0.0
    sat_position_y: float = 0.0
    sat_position_z: float = 0.0
    sat_velocity_x: float = 0.0
    sat_velocity_y: float = 0.0
    sat_velocity_z: float = 0.0
    spare: str = ""


@dataclass
class CalibrationInfo:
    """Block 5: Calibration Information"""
    header_block_number: int
    block_length: int
    band_number: int = 0
    central_wave_length: float = 0.0
    valid_number_of_bits_per_pixel: int = 0
    count_value_error_pixels: int = 0
    count_value_outside_scan_pixels: int = 0
    count_value_inside_scan_pixels: int = 0
    slope: float = 0.0
    intercept: float = 0.0
    spare: str = ""


@dataclass
class InterCalibrationInfo:
    """Block 5 extension: Inter-calibration Information"""
    header_block_number: int
    block_length: int
    gsics_correction_accuracy: float = 0.0
    count_value_radiance_bias: float = 0.0
    count_value_radiance_bias_uncertainty: float = 0.0
    count_value_radiance_gain: float = 0.0
    count_value_radiance_gain_uncertainty: float = 0.0
    spare: str = ""


@dataclass
class SegmentInfo:
    """Block 5 extension: Segment Information"""
    header_block_number: int
    block_length: int
    total_number_of_segments: int = 0
    segment_sequence_number: int = 0
    first_line_number_of_image_segment: int = 0
    spare: str = ""


@dataclass
class NavigationCorrectionInfo:
    """Block 5 extension: Navigation Correction Information"""
    header_block_number: int
    block_length: int
    column_correction_center_column_number: float = 0.0
    line_correction_center_line_number: float = 0.0
    column_correction_vec_1: float = 0.0
    column_correction_vec_2: float = 0.0
    column_correction_vec_3: float = 0.0
    line_correction_vec_1: float = 0.0
    line_correction_vec_2: float = 0.0
    line_correction_vec_3: float = 0.0
    spare1: str = ""
    column_scan_direction: float = 0.0
    line_scan_direction: float = 0.0
    spare2: str = ""


@dataclass
class ObservationTimeInfo:
    """Block 5 extension: Observation Time Information"""
    header_block_number: int
    block_length: int
    number_of_observation_times: int = 0
    observation_times: list = field(default_factory=list)


@dataclass
class ErrorInfo:
    """Block 5 extension: Error Information"""
    header_block_number: int
    block_length: int
    number_of_error_info_data: int = 0
    error_info_data: list = field(default_factory=list)


@dataclass
class SpareBlock:
    """Block 5 extension: Spare"""
    header_block_number: int
    block_length: int
    spare: str = ""


@dataclass
class HSDFile:
    """Complete HSD file with all headers and pixel data"""
    basic_info: BasicInfo
    data_info: DataInfo
    projection_info: ProjectionInfo
    navigation_info: NavigationInfo
    calibration_info: CalibrationInfo
    inter_calibration_info: Optional[InterCalibrationInfo] = None
    segment_info: Optional[SegmentInfo] = None
    navigation_correction_info: Optional[NavigationCorrectionInfo] = None
    observation_time_info: Optional[ObservationTimeInfo] = None
    error_info: Optional[ErrorInfo] = None
    spare_block: Optional[SpareBlock] = None
    pixel_data: Optional[np.ndarray] = None
    raw_data: Optional[np.ndarray] = None  # Uncalibrated raw counts


def _read_uchar(data: bytes, offset: int, length: int) -> Tuple[str, int]:
    """Read unsigned char string"""
    end = offset + length
    value = data[offset:end].decode('ascii', errors='replace').strip()
    return value, end


def _read_uint8(data: bytes, offset: int) -> Tuple[int, int]:
    """Read unsigned 8-bit integer"""
    return struct.unpack_from('>B', data, offset)[0], offset + 1


def _read_uint16(data: bytes, offset: int) -> Tuple[int, int]:
    """Read unsigned 16-bit big-endian integer"""
    return struct.unpack_from('>H', data, offset)[0], offset + 2


def _read_uint32(data: bytes, offset: int) -> Tuple[int, int]:
    """Read unsigned 32-bit big-endian integer"""
    return struct.unpack_from('>I', data, offset)[0], offset + 4


def _read_int32(data: bytes, offset: int) -> Tuple[int, int]:
    """Read signed 32-bit big-endian integer"""
    return struct.unpack_from('>i', data, offset)[0], offset + 4


def _read_float64(data: bytes, offset: int) -> Tuple[float, int]:
    """Read 64-bit big-endian float"""
    return struct.unpack_from('>d', data, offset)[0], offset + 8


def _read_real8(data: bytes, offset: int) -> Tuple[float, int]:
    """Read 8-byte real (float64)"""
    return struct.unpack_from('>d', data, offset)[0], offset + 8


def _read_int16(data: bytes, offset: int) -> Tuple[int, int]:
    """Read signed 16-bit big-endian integer"""
    return struct.unpack_from('>h', data, offset)[0], offset + 2


def parse_basic_info(data: bytes) -> BasicInfo:
    """Parse Block 1: Basic Information"""
    offset = 0
    block_num, offset = _read_uint16(data, offset)
    block_len, offset = _read_uint16(data, offset)
    
    info = BasicInfo(header_block_number=block_num, block_length=block_len)
    
    info.satellite_name, offset = _read_uchar(data, offset, 16)
    info.processing_center, offset = _read_uchar(data, offset, 4)
    info.observation_area, offset = _read_uchar(data, offset, 4)
    info.other_info, offset = _read_uchar(data, offset, 2)
    info.observation_timeline, offset = _read_uint16(data, offset)
    info.observation_start_time, offset = _read_uchar(data, offset, 32)
    info.observation_end_time, offset = _read_uchar(data, offset, 32)
    info.file_creation_time, offset = _read_uchar(data, offset, 32)
    info.total_header_length, offset = _read_uint32(data, offset)
    info.total_data_length, offset = _read_uint32(data, offset)
    info.quality_flag, offset = _read_uint8(data, offset)
    info.spare, offset = _read_uchar(data, offset, 40)
    
    return info


def parse_data_info(data: bytes) -> DataInfo:
    """Parse Block 2: Data Information"""
    offset = 0
    block_num, offset = _read_uint16(data, offset)
    block_len, offset = _read_uint16(data, offset)
    
    info = DataInfo(header_block_number=block_num, block_length=block_len)
    
    info.bits_per_pixel, offset = _read_uint16(data, offset)
    info.number_of_columns, offset = _read_uint16(data, offset)
    info.number_of_lines, offset = _read_uint16(data, offset)
    info.compression_flag, offset = _read_uint8(data, offset)
    info.spare, offset = _read_uchar(data, offset, 40)
    
    return info


def parse_projection_info(data: bytes) -> ProjectionInfo:
    """Parse Block 3: Projection Information"""
    offset = 0
    block_num, offset = _read_uint16(data, offset)
    block_len, offset = _read_uint16(data, offset)
    
    info = ProjectionInfo(header_block_number=block_num, block_length=block_len)
    
    info.sub_lon, offset = _read_real8(data, offset)
    info.sub_lat, offset = _read_real8(data, offset)
    info.distance_earth_center_to_satellite, offset = _read_real8(data, offset)
    info.equatorial_radius, offset = _read_real8(data, offset)
    info.polar_radius, offset = _read_real8(data, offset)
    info.cfac, offset = _read_real8(data, offset)
    info.lfac, offset = _read_real8(data, offset)
    info.coff, offset = _read_real8(data, offset)
    info.loff, offset = _read_real8(data, offset)
    info.image_flip_e_w, offset = _read_uint8(data, offset)
    info.image_flip_n_s, offset = _read_uint8(data, offset)
    info.spare, offset = _read_uchar(data, offset, 52)
    
    # Compute georeferencing
    info = _compute_georeferencing(info)
    
    return info


def _compute_georeferencing(info: ProjectionInfo) -> ProjectionInfo:
    """Compute GeoTIFF georeferencing parameters from projection info"""
    # For geostationary projection
    # cfac and lfac are in radians per pixel, scaled by 2^16
    # Resolution in radians
    col_res = info.cfac / (2 ** 16)  # radians per pixel (column)
    line_res = info.lfac / (2 ** 16)  # radians per pixel (line)
    
    # Satellite height from Earth center
    sat_height = info.distance_earth_center_to_satellite  # in meters
    
    # Pixel size in meters at satellite distance
    # x_size = sat_height * col_res
    # y_size = sat_height * line_res (negative because lines increase southward)
    x_size = sat_height * col_res
    y_size = -(sat_height * line_res)
    
    # Origin (top-left corner of top-left pixel)
    # coff and loff are 1-based center coordinates of the reference pixel
    x_origin = -(info.coff - 1) * x_size
    y_origin = -(info.loff - 1) * y_size
    
    info.geotransform = (x_origin, x_size, 0.0, y_origin, 0.0, y_size)
    
    # Geostationary CRS WKT
    sub_lon_deg = info.sub_lon
    info.crs_wkt = _create_geos_wkt(sub_lon_deg)
    
    return info


def _create_geos_wkt(sub_lon_deg: float) -> str:
    """Create Geostationary CRS WKT string"""
    return (
        f'GEOGCS["WGS 84",'
        f'DATUM["WGS_1984",'
        f'SPHEROID["WGS 84",6378137,298.257223563]],'
        f'PRIMEM["Greenwich",0],'
        f'UNIT["Degree",0.0174532925199433]]'
    )


def parse_navigation_info(data: bytes) -> NavigationInfo:
    """Parse Block 4: Navigation Information"""
    offset = 0
    block_num, offset = _read_uint16(data, offset)
    block_len, offset = _read_uint16(data, offset)
    
    info = NavigationInfo(header_block_number=block_num, block_length=block_len)
    
    info.sat_position_x, offset = _read_real8(data, offset)
    info.sat_position_y, offset = _read_real8(data, offset)
    info.sat_position_z, offset = _read_real8(data, offset)
    info.sat_velocity_x, offset = _read_real8(data, offset)
    info.sat_velocity_y, offset = _read_real8(data, offset)
    info.sat_velocity_z, offset = _read_real8(data, offset)
    info.spare, offset = _read_uchar(data, offset, 40)
    
    return info


def parse_calibration_info(data: bytes) -> CalibrationInfo:
    """Parse Block 5: Calibration Information"""
    offset = 0
    block_num, offset = _read_uint16(data, offset)
    block_len, offset = _read_uint16(data, offset)
    
    info = CalibrationInfo(header_block_number=block_num, block_length=block_len)
    
    info.band_number, offset = _read_uint16(data, offset)
    info.central_wave_length, offset = _read_real8(data, offset)
    info.valid_number_of_bits_per_pixel, offset = _read_uint16(data, offset)
    info.count_value_error_pixels, offset = _read_int16(data, offset)
    info.count_value_outside_scan_pixels, offset = _read_int16(data, offset)
    info.count_value_inside_scan_pixels, offset = _read_int16(data, offset)
    info.slope, offset = _read_real8(data, offset)
    info.intercept, offset = _read_real8(data, offset)
    info.spare, offset = _read_uchar(data, offset, 80)
    
    return info


def parse_inter_calibration_info(data: bytes) -> InterCalibrationInfo:
    """Parse Block 5 extension: Inter-calibration Information"""
    offset = 0
    block_num, offset = _read_uint16(data, offset)
    block_len, offset = _read_uint16(data, offset)
    
    info = InterCalibrationInfo(header_block_number=block_num, block_length=block_len)
    
    info.gsics_correction_accuracy, offset = _read_real8(data, offset)
    info.count_value_radiance_bias, offset = _read_real8(data, offset)
    info.count_value_radiance_bias_uncertainty, offset = _read_real8(data, offset)
    info.count_value_radiance_gain, offset = _read_real8(data, offset)
    info.count_value_radiance_gain_uncertainty, offset = _read_real8(data, offset)
    info.spare, offset = _read_uchar(data, offset, 40)
    
    return info


def parse_segment_info(data: bytes) -> SegmentInfo:
    """Parse Block 5 extension: Segment Information"""
    offset = 0
    block_num, offset = _read_uint16(data, offset)
    block_len, offset = _read_uint16(data, offset)
    
    info = SegmentInfo(header_block_number=block_num, block_length=block_len)
    
    info.total_number_of_segments, offset = _read_uint8(data, offset)
    info.segment_sequence_number, offset = _read_uint8(data, offset)
    info.first_line_number_of_image_segment, offset = _read_uint16(data, offset)
    info.spare, offset = _read_uchar(data, offset, 40)
    
    return info


def parse_navigation_correction_info(data: bytes) -> NavigationCorrectionInfo:
    """Parse Block 5 extension: Navigation Correction Information"""
    offset = 0
    block_num, offset = _read_uint16(data, offset)
    block_len, offset = _read_uint16(data, offset)
    
    info = NavigationCorrectionInfo(header_block_number=block_num, block_length=block_len)
    
    info.column_correction_center_column_number, offset = _read_real8(data, offset)
    info.line_correction_center_line_number, offset = _read_real8(data, offset)
    info.column_correction_vec_1, offset = _read_real8(data, offset)
    info.column_correction_vec_2, offset = _read_real8(data, offset)
    info.column_correction_vec_3, offset = _read_real8(data, offset)
    info.line_correction_vec_1, offset = _read_real8(data, offset)
    info.line_correction_vec_2, offset = _read_real8(data, offset)
    info.line_correction_vec_3, offset = _read_real8(data, offset)
    info.spare1, offset = _read_uchar(data, offset, 24)
    info.column_scan_direction, offset = _read_real8(data, offset)
    info.line_scan_direction, offset = _read_real8(data, offset)
    info.spare2, offset = _read_uchar(data, offset, 16)
    
    return info


def parse_observation_time_info(data: bytes) -> ObservationTimeInfo:
    """Parse Block 5 extension: Observation Time Information"""
    offset = 0
    block_num, offset = _read_uint16(data, offset)
    block_len, offset = _read_uint16(data, offset)
    
    info = ObservationTimeInfo(header_block_number=block_num, block_length=block_len)
    info.number_of_observation_times, offset = _read_uint16(data, offset)
    
    times = []
    for _ in range(info.number_of_observation_times):
        t, offset = _read_uchar(data, offset, 32)
        times.append(t)
    info.observation_times = times
    
    return info


def parse_error_info(data: bytes) -> ErrorInfo:
    """Parse Block 5 extension: Error Information"""
    offset = 0
    block_num, offset = _read_uint16(data, offset)
    block_len, offset = _read_uint16(data, offset)
    
    info = ErrorInfo(header_block_number=block_num, block_length=block_len)
    info.number_of_error_info_data, offset = _read_uint16(data, offset)
    
    errors = []
    for _ in range(info.number_of_error_info_data):
        err_data = {}
        err_data['line_number'], offset = _read_uint16(data, offset)
        err_data['line_validity'], offset = _read_uint16(data, offset)
        errors.append(err_data)
    info.error_info_data = errors
    
    return info


def parse_spare_block(data: bytes) -> SpareBlock:
    """Parse Block 5 extension: Spare"""
    offset = 0
    block_num, offset = _read_uint16(data, offset)
    block_len, offset = _read_uint16(data, offset)
    
    info = SpareBlock(header_block_number=block_num, block_length=block_len)
    info.spare, offset = _read_uchar(data, offset, block_len - 4)
    
    return info


def parse_data_block(data: bytes, ncols: int, nlines: int, bpp: int) -> np.ndarray:
    """Parse Block 6: Data Block (pixel data)
    
    Args:
        data: Raw pixel data bytes (after block header)
        ncols: Number of columns
        nlines: Number of lines
        bpp: Bits per pixel (16 for IR, 11 for visible)
    
    Returns:
        numpy array of shape (nlines, ncols) with dtype uint16
    """
    bytes_per_pixel = bpp // 8 if bpp % 8 == 0 else 2  # Use 2 bytes minimum
    expected_size = nlines * ncols * bytes_per_pixel
    
    if len(data) < expected_size:
        logger.warning(f"Data block smaller than expected: {len(data)} < {expected_size}")
        # Pad with zeros
        data = data + b'\x00' * (expected_size - len(data))
    
    # Parse as big-endian uint16
    pixel_data = np.frombuffer(data[:expected_size], dtype='>u2').reshape((nlines, ncols))
    
    # Convert to native endian
    pixel_data = pixel_data.astype(np.uint16)
    
    # Mask error values (0xFFFF = 65535)
    pixel_data = np.where(pixel_data == 65535, 0, pixel_data)
    
    return pixel_data


def parse_hsd_file(file_data: bytes) -> HSDFile:
    """Parse a complete HSD file from binary data.
    
    Args:
        file_data: Complete HSD file binary data (may be bz2 compressed externally)
    
    Returns:
        HSDFile dataclass with all headers and pixel data
    """
    offset = 0
    total_len = len(file_data)
    
    logger.info(f"Parsing HSD file of {total_len} bytes")
    
    # Parse Block 1: Basic Information
    block_num, block_len = struct.unpack_from('>HH', file_data, offset)
    logger.info(f"Block 1: num={block_num}, len={block_len}")
    basic_info = parse_basic_info(file_data[offset:offset + block_len])
    offset += block_len
    
    # Parse Block 2: Data Information
    block_num, block_len = struct.unpack_from('>HH', file_data, offset)
    logger.info(f"Block 2: num={block_num}, len={block_len}")
    data_info = parse_data_info(file_data[offset:offset + block_len])
    offset += block_len
    
    # Parse Block 3: Projection Information
    block_num, block_len = struct.unpack_from('>HH', file_data, offset)
    logger.info(f"Block 3: num={block_num}, len={block_len}")
    projection_info = parse_projection_info(file_data[offset:offset + block_len])
    offset += block_len
    
    # Parse Block 4: Navigation Information
    block_num, block_len = struct.unpack_from('>HH', file_data, offset)
    logger.info(f"Block 4: num={block_num}, len={block_len}")
    navigation_info = parse_navigation_info(file_data[offset:offset + block_len])
    offset += block_len
    
    # Parse Block 5 and extensions: Calibration Information
    block_num, block_len = struct.unpack_from('>HH', file_data, offset)
    logger.info(f"Block 5: num={block_num}, len={block_len}")
    calibration_info = parse_calibration_info(file_data[offset:offset + block_len])
    offset += block_len
    
    # Parse remaining Block 5 extensions
    inter_calibration_info = None
    segment_info = None
    navigation_correction_info = None
    observation_time_info = None
    error_info = None
    spare_block = None
    
    # Continue parsing extensions until we reach block 6
    while offset < total_len:
        if offset + 4 > total_len:
            break
        
        block_num, block_len = struct.unpack_from('>HH', file_data, offset)
        
        if block_num == 6:
            # Data block
            break
        
        logger.info(f"Block 5 extension: num={block_num}, len={block_len}")
        block_data = file_data[offset:offset + block_len]
        
        # Try to identify the extension by block number pattern
        # In HSD, extensions typically have block numbers 5x
        if block_num == 51 or block_num == 5:  # Inter-calibration
            inter_calibration_info = parse_inter_calibration_info(block_data)
        elif block_num == 52:  # Segment
            segment_info = parse_segment_info(block_data)
        elif block_num == 53:  # Navigation correction
            navigation_correction_info = parse_navigation_correction_info(block_data)
        elif block_num == 54:  # Observation time
            observation_time_info = parse_observation_time_info(block_data)
        elif block_num == 55:  # Error info
            error_info = parse_error_info(block_data)
        elif block_num == 60 or block_num == 255:  # Spare
            spare_block = parse_spare_block(block_data)
        else:
            # Unknown extension, try to skip it
            logger.warning(f"Unknown block extension: num={block_num}, len={block_len}, skipping")
        
        offset += block_len
    
    # Parse Block 6: Data Block
    if offset < total_len:
        block_num, block_len = struct.unpack_from('>HH', file_data, offset)
        logger.info(f"Block 6: num={block_num}, len={block_len}")
        
        # Skip block header (4 bytes)
        data_offset = offset + 4
        data_size = block_len - 4
        pixel_data = parse_data_block(
            file_data[data_offset:data_offset + data_size],
            data_info.number_of_columns,
            data_info.number_of_lines,
            data_info.bits_per_pixel
        )
    else:
        logger.error("No data block found in HSD file")
        pixel_data = np.zeros(
            (data_info.number_of_lines, data_info.number_of_columns),
            dtype=np.uint16
        )
    
    return HSDFile(
        basic_info=basic_info,
        data_info=data_info,
        projection_info=projection_info,
        navigation_info=navigation_info,
        calibration_info=calibration_info,
        inter_calibration_info=inter_calibration_info,
        segment_info=segment_info,
        navigation_correction_info=navigation_correction_info,
        observation_time_info=observation_time_info,
        error_info=error_info,
        spare_block=spare_block,
        raw_data=pixel_data.copy(),
        pixel_data=pixel_data
    )


def calibrate_data(hsd_file: HSDFile) -> np.ndarray:
    """Convert raw counts to calibrated values (Albedo or Brightness Temperature).
    
    Uses the calibration slope and intercept from Block 5:
    calibrated_value = slope * raw_count + intercept
    
    For visible bands: result is Albedo (%)
    For IR bands: result is Brightness Temperature (K)
    """
    raw = hsd_file.pixel_data.astype(np.float32)
    slope = float(hsd_file.calibration_info.slope)
    intercept = float(hsd_file.calibration_info.intercept)
    
    calibrated = slope * raw + intercept
    
    return calibrated
