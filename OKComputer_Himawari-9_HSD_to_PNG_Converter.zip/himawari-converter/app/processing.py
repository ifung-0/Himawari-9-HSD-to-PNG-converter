"""
HSD Processing Pipeline: HSD -> GeoTIFF -> PNG

Pipeline:
1. Decompress .dat.bz2 -> HSD binary
2. Parse HSD headers and pixel data
3. Calibrate to physical units (Albedo or Brightness Temperature)
4. Create GeoTIFF with geostationary CRS
5. Render to PNG with enhancements
"""

import io
import logging
import tempfile
import os
from typing import Optional, Tuple, BinaryIO
from pathlib import Path

import numpy as np
from PIL import Image, ImageEnhance

try:
    import rasterio
    from rasterio.crs import CRS
    from rasterio.transform import from_origin
    from rasterio.enums import Compression
    RASTERIO_AVAILABLE = True
except ImportError:
    RASTERIO_AVAILABLE = False
    logging.warning("rasterio not available - GeoTIFF creation will be limited")

from app.hsd_parser import HSDFile, calibrate_data, ProjectionInfo

logger = logging.getLogger(__name__)


def create_geotiff(
    hsd_file: HSDFile,
    output_path: Optional[str] = None,
    calibrated_data: Optional[np.ndarray] = None
) -> bytes:
    """Create a GeoTIFF from HSD data with geostationary CRS.
    
    Args:
        hsd_file: Parsed HSD file
        output_path: Optional file path to write to
        calibrated_data: Pre-calibrated data (if None, will calibrate)
    
    Returns:
        GeoTIFF as bytes if output_path is None
    """
    if not RASTERIO_AVAILABLE:
        raise ImportError("rasterio is required for GeoTIFF creation")
    
    if calibrated_data is None:
        calibrated_data = calibrate_data(hsd_file)
    
    proj = hsd_file.projection_info
    data_info = hsd_file.data_info
    
    nlines = data_info.number_of_lines
    ncols = data_info.number_of_columns
    
    # Ensure data is float32 for TIFF
    if calibrated_data.dtype != np.float32:
        calibrated_data = calibrated_data.astype(np.float32)
    
    # Handle shape - if 3D (multi-band), use as-is, if 2D, add band dimension
    if len(calibrated_data.shape) == 2:
        calibrated_data = calibrated_data[np.newaxis, :, :]
    
    nbands = calibrated_data.shape[0]
    
    # Create affine transform from geotransform
    transform = Affine.from_gdal(*proj.geotransform)
    
    # Build Geostationary CRS
    sub_lon = proj.sub_lon
    crs_str = (
        f'PROJCS["GEOS({sub_lon})",'
        f'GEOGCS["WGS 84",'
        f'DATUM["WGS_1984",'
        f'SPHEROID["WGS 84",6378137,298.257223563,AUTHORITY["EPSG","7030"]],'
        f'AUTHORITY["EPSG","6326"]],'
        f'PRIMEM["Greenwich",0,AUTHORITY["EPSG","8901"]],'
        f'UNIT["degree",0.0174532925199433,AUTHORITY["EPSG","9122"]],'
        f'AUTHORITY["EPSG","4326"]],'
        f'PROJECTION["Geostationary_Satellite"],'
        f'PARAMETER["central_meridian",{sub_lon}],'
        f'PARAMETER["satellite_height",{proj.distance_earth_center_to_satellite - 6378137}],'
        f'PARAMETER["false_easting",0],'
        f'PARAMETER["false_northing",0],'
        f'UNIT["metre",1,AUTHORITY["EPSG","9001"]],'
        f'AXIS["Easting",EAST],'
        f'AXIS["Northing",NORTH],'
        f'EXTENSION["PROJ4","+proj=geos +h={proj.distance_earth_center_to_satellite - 6378137:.3f} +lon_0={sub_lon} +sweep=y +ellps=WGS84 +units=m +no_defs"]]'
    )
    
    crs = CRS.from_wkt(crs_str)
    
    # Create metadata
    meta = {
        'driver': 'GTiff',
        'height': nlines,
        'width': ncols,
        'count': nbands,
        'dtype': 'float32',
        'crs': crs,
        'transform': transform,
        'compress': 'lzw',
        'nodata': 0,
    }
    
    if output_path:
        with rasterio.open(output_path, 'w', **meta) as dst:
            for i in range(nbands):
                dst.write(calibrated_data[i], i + 1)
            # Add metadata
            dst.update_tags(
                satellite=hsd_file.basic_info.satellite_name,
                band=str(hsd_file.calibration_info.band_number),
                wavelength=str(hsd_file.calibration_info.central_wave_length),
                observation_start=hsd_file.basic_info.observation_start_time,
                observation_end=hsd_file.basic_info.observation_end_time,
            )
        return None
    else:
        # Write to memory
        memfile = io.BytesIO()
        with rasterio.MemoryFile() as mem:
            with mem.open(**meta) as dst:
                for i in range(nbands):
                    dst.write(calibrated_data[i], i + 1)
                dst.update_tags(
                    satellite=hsd_file.basic_info.satellite_name,
                    band=str(hsd_file.calibration_info.band_number),
                    wavelength=str(hsd_file.calibration_info.central_wave_length),
                    observation_start=hsd_file.basic_info.observation_start_time,
                    observation_end=hsd_file.basic_info.observation_end_time,
                )
            memfile.write(mem.read())
        
        memfile.seek(0)
        return memfile.read()


def apply_enhancement(
    data: np.ndarray,
    enhancement: str = "linear",
    band_type: str = "ir"
) -> np.ndarray:
    """Apply image enhancement to calibrated data.
    
    Args:
        data: Calibrated float32 array
        enhancement: One of 'linear', 'albedo', 'histogram'
        band_type: 'ir' or 'visible'
    
    Returns:
        Enhanced uint8 array (0-255)
    """
    data = np.nan_to_num(data, nan=0.0, posinf=0.0, neginf=0.0)
    
    if enhancement == "linear":
        # Simple linear stretch to 0-255
        dmin, dmax = np.percentile(data[data > 0], [1, 99])
        if dmax <= dmin:
            dmax = dmin + 1
        stretched = np.clip((data - dmin) / (dmax - dmin) * 255, 0, 255)
        
    elif enhancement == "albedo":
        # For visible bands, data is albedo in % (0-100)
        if band_type == "visible":
            stretched = np.clip(data * 2.55, 0, 255)  # 100% -> 255
        else:
            # For IR, use reversed scale (cold = bright)
            dmin, dmax = np.percentile(data[data > 0], [1, 99])
            if dmax <= dmin:
                dmax = dmin + 1
            stretched = np.clip((dmax - data) / (dmax - dmin) * 255, 0, 255)
            
    elif enhancement == "histogram":
        # Histogram equalization
        data_flat = data.flatten()
        valid = data_flat[data_flat > 0]
        
        if len(valid) > 0:
            hist, bins = np.histogram(valid, bins=256)
            cdf = hist.cumsum()
            cdf = (cdf - cdf.min()) / (cdf.max() - cdf.min()) * 255
            
            # Map each pixel to its CDF value
            indices = np.searchsorted(bins[:-1], data_flat)
            indices = np.clip(indices, 0, 255)
            stretched = cdf[indices].reshape(data.shape)
        else:
            stretched = np.zeros_like(data)
    else:
        # Default linear
        dmin, dmax = data.min(), data.max()
        if dmax <= dmin:
            dmax = dmin + 1
        stretched = np.clip((data - dmin) / (dmax - dmin) * 255, 0, 255)
    
    return stretched.astype(np.uint8)


def apply_gamma_correction(data: np.ndarray, gamma: float = 2.2) -> np.ndarray:
    """Apply gamma correction to uint8 data.
    
    Args:
        data: uint8 array (0-255)
        gamma: Gamma value (default 2.2 for sRGB)
    
    Returns:
        Gamma-corrected uint8 array
    """
    # Normalize to 0-1, apply gamma, then scale back
    normalized = data.astype(np.float32) / 255.0
    corrected = np.power(normalized, 1.0 / gamma)
    return np.clip(corrected * 255, 0, 255).astype(np.uint8)


def render_to_png(
    hsd_file: HSDFile,
    enhancement: str = "linear",
    apply_gamma: bool = True,
    gamma_value: float = 2.2,
    contrast_factor: float = 1.0
) -> bytes:
    """Render HSD data to PNG image.
    
    Args:
        hsd_file: Parsed HSD file
        enhancement: Enhancement type ('linear', 'albedo', 'histogram')
        apply_gamma: Whether to apply gamma correction
        gamma_value: Gamma correction value
        contrast_factor: Contrast enhancement factor (1.0 = no change)
    
    Returns:
        PNG image as bytes
    """
    # Calibrate data
    calibrated = calibrate_data(hsd_file)
    
    # Determine band type
    band_num = hsd_file.calibration_info.band_number
    band_type = "visible" if band_num <= 6 else "ir"
    
    # Apply enhancement
    enhanced = apply_enhancement(calibrated, enhancement, band_type)
    
    # Apply gamma correction
    if apply_gamma:
        enhanced = apply_gamma_correction(enhanced, gamma_value)
    
    # Create PIL Image
    img = Image.fromarray(enhanced, mode='L')
    
    # Apply contrast enhancement
    if contrast_factor != 1.0:
        enhancer = ImageEnhance.Contrast(img)
        img = enhancer.enhance(contrast_factor)
    
    # Save to bytes
    output = io.BytesIO()
    img.save(output, format='PNG', optimize=True)
    output.seek(0)
    
    return output.getvalue()


def create_truecolor_composite(
    b01_hsd: HSDFile,  # Blue band
    b02_hsd: HSDFile,  # Green band
    b03_hsd: HSDFile,  # Red band
    green_correction: float = 0.45,
    enhancement: str = "linear",
    apply_gamma: bool = True,
    gamma_value: float = 2.2
) -> bytes:
    """Create true-color RGB composite from B01, B02, B03 bands.
    
    JMA Standard Green Correction:
    Green = B02 * (1 - alpha) + B03 * alpha
    where alpha is typically 0.45
    
    This compensates for the lack of a dedicated green band on Himawari.
    
    Args:
        b01_hsd: Blue band (B01) HSD file
        b02_hsd: Green band (B02) HSD file
        b03_hsd: Red band (B03) HSD file
        green_correction: Green correction factor (default 0.45)
        enhancement: Enhancement type
        apply_gamma: Apply gamma correction
        gamma_value: Gamma value
    
    Returns:
        PNG RGB image as bytes
    """
    # Calibrate each band
    b01_cal = calibrate_data(b01_hsd)
    b02_cal = calibrate_data(b02_hsd)
    b03_cal = calibrate_data(b03_hsd)
    
    # These are visible bands (albedo in %)
    # For true color, we use B03 (Red), corrected Green, B01 (Blue)
    
    # Apply green correction: G = B02 * (1 - alpha) + B03 * alpha
    green_corrected = b02_cal * (1 - green_correction) + b03_cal * green_correction
    
    # Stack to RGB (all should be same shape)
    nlines = b01_hsd.data_info.number_of_lines
    ncols = b01_hsd.data_info.number_of_columns
    
    # Ensure consistent shapes
    if b03_cal.shape != (nlines, ncols):
        b03_cal = _resize_array(b03_cal, (nlines, ncols))
    if green_corrected.shape != (nlines, ncols):
        green_corrected = _resize_array(green_corrected, (nlines, ncols))
    if b01_cal.shape != (nlines, ncols):
        b01_cal = _resize_array(b01_cal, (nlines, ncols))
    
    # Apply enhancement to each channel
    red = apply_enhancement(b03_cal, enhancement, "visible")
    green = apply_enhancement(green_corrected, enhancement, "visible")
    blue = apply_enhancement(b01_cal, enhancement, "visible")
    
    # Apply gamma correction
    if apply_gamma:
        red = apply_gamma_correction(red, gamma_value)
        green = apply_gamma_correction(green, gamma_value)
        blue = apply_gamma_correction(blue, gamma_value)
    
    # Stack to RGB
    rgb = np.stack([red, green, blue], axis=-1)
    
    # Create PIL Image
    img = Image.fromarray(rgb, mode='RGB')
    
    # Save to bytes
    output = io.BytesIO()
    img.save(output, format='PNG', optimize=True)
    output.seek(0)
    
    return output.getvalue()


def _resize_array(arr: np.ndarray, target_shape: Tuple[int, int]) -> np.ndarray:
    """Resize numpy array to target shape using simple interpolation."""
    from PIL import Image
    
    img = Image.fromarray(arr)
    img = img.resize((target_shape[1], target_shape[0]), Image.BILINEAR)
    return np.array(img)


# Import affine here to avoid issues if rasterio is not available
try:
    from affine import Affine
except ImportError:
    pass
