# Himawari-9 HSD to PNG Converter

A production-ready web application that converts Himawari-9 satellite data (HSD format `.dat.bz2` files) to downloadable PNG images, with optional true-color reproduction. The processing pipeline converts raw HSD data to GeoTIFF first, then renders to PNG.

## Features

- **Single Band Conversion**: Convert any Himawari-9 band to PNG or GeoTIFF
- **True Color RGB Composite**: Combine B01 (Blue), B02 (Green), and B03 (Red) with JMA-standard green correction
- **Image Enhancements**: Linear stretch, Albedo/Temperature, and Histogram Equalization
- **Georeferenced Output**: GeoTIFF files include Geostationary CRS metadata
- **Real-time Progress**: Web UI shows download and processing progress
- **Comprehensive Error Handling**: Clear error messages for all failure scenarios

## Quick Start (GitHub Codespaces)

1. Click **"Open in GitHub Codespaces"** button (or use `.devcontainer/devcontainer.json`)
2. The environment auto-configures with all dependencies
3. The server starts automatically on port 8000
4. Open the preview URL to access the converter UI

## Local Development

```bash
# Clone the repository
git clone <repo-url>
cd himawari-converter

# Create virtual environment
python -m venv venv
source venv/bin/activate  # Linux/Mac
# or: venv\Scripts\activate  # Windows

# Install dependencies
pip install -r requirements.txt

# Run tests
pytest tests/ -v

# Start server
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

Open `http://localhost:8000` in your browser.

## API Endpoints

### `GET /convert`

Convert a single HSD file to PNG or GeoTIFF.

**Parameters:**
| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `url` | string | Yes | S3 URL to `.dat.bz2` file |
| `format` | string | No | Output format: `png` (default) or `tiff` |
| `enhancement` | string | No | Enhancement: `linear` (default), `albedo`, `histogram` |

**Example:**
```
GET /convert?url=https://noaa-himawari9.s3.amazonaws.com/HSF-ext/202401/15/06/B03/HS_H09_20240115_0600_B03_FLDK_R20_S0510.DAT.bz2&format=png&enhancement=linear
```

### `GET /truecolor`

Create true-color RGB composite from B01, B02, B03 bands.

**Parameters:**
| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `b01_url` | string | Yes | S3 URL for B01 (Blue, 470nm) |
| `b02_url` | string | Yes | S3 URL for B02 (Green, 510nm) |
| `b03_url` | string | Yes | S3 URL for B03 (Red, 640nm) |
| `format` | string | No | Output format: `png` (default) or `tiff` |
| `green_correction` | float | No | Green correction factor 0-1 (default: 0.45) |
| `enhancement` | string | No | Enhancement: `linear` (default), `albedo`, `histogram` |

**Example:**
```
GET /truecolor?b01_url=...&b02_url=...&b03_url=...&green_correction=0.45
```

### `GET /health`

Health check endpoint.

## Processing Pipeline

1. **Decompress**: `.dat.bz2` -> bzip2 decompress -> HSD binary data
2. **Parse**: Extract HSD headers and pixel data into numpy arrays
3. **Calibrate**: Convert to calibrated float32 (Albedo or Brightness Temperature)
4. **Create GeoTIFF**: Embed georeferencing from Block 3 with Geostationary CRS
5. **Render to PNG**: Apply gamma correction (2.2) and contrast enhancement

## HSD Format

The Himawari Standard Data format consists of sequential blocks:

| Block | Content |
|-------|---------|
| 1 | Basic Information (satellite, area, timestamps) |
| 2 | Data Information (bits/pixel, dimensions) |
| 3 | Projection Information (sub-satellite point, scaling factors) |
| 4 | Navigation Information (satellite position/velocity) |
| 5 | Calibration Information (slope, intercept) |
| 6 | Pixel Data (nlines x ncols x 2 bytes) |

## Error Codes

| Code | Error | Cause | Fix |
|------|-------|-------|-----|
| 400 | Invalid URL | URL not from NOAA S3 | Use noaa-himawari9.s3.amazonaws.com |
| 400 | Invalid format | Not png/tiff | Use png or tiff |
| 400 | Invalid enhancement | Unknown type | Use linear, albedo, or histogram |
| 400 | Invalid green correction | Outside 0-1 range | Use value between 0 and 1 |
| 404 | Not Found | File doesn't exist | Check date/time; data kept ~2 weeks |
| 413 | Payload Too Large | File over 500MB | Use lower resolution (R10) |
| 504 | Gateway Timeout | Network timeout | Check connection or try smaller file |
| 500 | Internal Error | Parser/processing error | Check logs and HSD block integrity |

## Green Correction

Himawari-9 lacks a dedicated green band. The JMA standard green correction:

```
Green = B02 * (1 - alpha) + B03 * alpha
```

Default `alpha = 0.45` is the JMA recommended value.

## Data Source

Data is available from the JMA Himawari-8/9 Cloud Service via NOAA S3:
- Base URL: `https://noaa-himawari9.s3.amazonaws.com`
- Format: `HSF-ext/YYYYMM/DD/HH/B##/HS_H09_YYYYMMDD_HHMM_B##_FLDK_R##_S####.DAT.bz2`
- Resolution codes: R05 (0.5km), R10 (1km), R20 (2km), R40 (4km)

## Project Structure

```
himawari-converter/
  app/
    __init__.py
    main.py              # FastAPI application
    hsd_parser.py        # HSD binary format parser
    processing.py        # TIFF/PNG rendering pipeline
    static/
      index.html         # Web UI
  tests/
    test_api.py          # API endpoint tests (25 tests)
    test_parser.py       # HSD parser tests (13 tests)
  .devcontainer/
    devcontainer.json    # GitHub Codespaces config
  requirements.txt       # Python dependencies
  pytest.ini            # Test configuration
  README.md
```

## Testing

```bash
# Run all tests
pytest tests/ -v

# Run specific test file
pytest tests/test_api.py -v
pytest tests/test_parser.py -v

# Run with coverage
pytest tests/ --cov=app --cov-report=html
```

## Technology Stack

- **Backend**: FastAPI, asyncio, httpx
- **Data Processing**: numpy, Pillow, rasterio (GeoTIFF)
- **Compression**: bz2 (stdlib)
- **Parser**: Custom binary parser (no external HSD libraries)
- **Frontend**: Vanilla HTML/CSS/JS (no build step)
- **Testing**: pytest, pytest-asyncio

## License

MIT License
